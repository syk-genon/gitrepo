#!/usr/bin/env bash
# MinIO(NAS PVC) + 전처리기 동시 장애 점검 스크립트
#
# [읽기 전용] 이 스크립트는 클러스터/노드 상태를 조회만 한다.
#   - 파드 재시작·삭제·스케일 등 상태를 바꾸는 명령은 포함하지 않는다.
#   - 원인 확정 전에 MinIO/전처리기 파드를 재시작하면 lastState·previous 로그 등 증거가 사라진다.
#
# 사용법
#   1) 클러스터 점검 (kubectl 사용 가능한 곳)
#        ./minio_nas_check.sh cluster [-n llmops] [-s 6h] [-p http://<prometheus>:9090]
#   2) 노드 점검 (MinIO 파드가 떠 있던 노드에 SSH 접속 후, 1)의 결과 끝에 명령이 출력됨)
#        sudo ./minio_nas_check.sh node -v <PV이름> [-f "2026-10-07 09:00"] [-u "2026-10-07 12:00"]
#
# 결과: ./minio_nas_check_<mode>_<host>_<timestamp>/ 디렉터리와 같은 이름의 .tar.gz

set -u

MODE="${1:-}"
[ $# -gt 0 ] && shift

NS="llmops"
SINCE="6h"
PROM_URL=""
PV_NAME=""
J_FROM=""
J_UNTIL=""
CMD_TIMEOUT=30          # 개별 조회 명령 상한(초)
NFS_PROBE_TIMEOUT=10    # NFS 경로 응답 측정 상한(초)
NFS_SLOW_SEC=5          # 이 이상 걸리면 NAS 지연으로 판정
LOG_TAIL=300

usage() {
  sed -n '2,15p' "$0" | sed 's/^# \{0,1\}//'
  exit 1
}

while getopts "n:s:p:v:f:u:h" opt; do
  case "$opt" in
    n) NS="$OPTARG" ;;
    s) SINCE="$OPTARG" ;;
    p) PROM_URL="${OPTARG%/}" ;;
    v) PV_NAME="$OPTARG" ;;
    f) J_FROM="$OPTARG" ;;
    u) J_UNTIL="$OPTARG" ;;
    *) usage ;;
  esac
done

case "$MODE" in cluster|node) ;; *) usage ;; esac

TS="$(date +%Y%m%d_%H%M%S)"
OUT="./minio_nas_check_${MODE}_$(hostname -s)_${TS}"
mkdir -p "$OUT"
SUMMARY="$OUT/00_summary.txt"

note()    { echo "$*" >> "$SUMMARY"; }
section() { echo; echo "=== $* ==="; } >> "$SUMMARY"
# run <file> <shell command string>: 명령과 결과를 파일에 남긴다(타임아웃 적용)
run() {
  local f="$OUT/$1"; shift
  { echo "\$ $*"; timeout "$CMD_TIMEOUT" bash -c "$*" 2>&1; echo "[exit $?]"; echo; } >> "$f"
}

since_to_sec() {
  local v="${1%[smhd]}" u="${1: -1}"
  case "$u" in s) echo "$v" ;; m) echo $((v*60)) ;; h) echo $((v*3600)) ;; d) echo $((v*86400)) ;; *) echo $(( $1 * 1 )) ;; esac
}

# ---------------------------------------------------------------- cluster
cluster_check() {
  command -v kubectl >/dev/null || { echo "kubectl 없음"; exit 1; }
  local K="kubectl --request-timeout=20s"

  note "[cluster] ns=$NS since=$SINCE context=$($K config current-context 2>/dev/null)"
  note "결과 디렉터리: $OUT"

  local minio_pods prep_pods
  minio_pods=$($K -n "$NS" get pod -o name 2>/dev/null | grep -i minio)
  prep_pods=$($K -n "$NS" get pod -o name 2>/dev/null | grep -iE "preprocess")
  [ -z "$minio_pods" ] && note "!! $NS 네임스페이스에서 minio 파드를 찾지 못함"

  # 1. 종료 사유 (env 값 노출을 피하려고 describe 대신 jsonpath 사용)
  local JP='{range .status.containerStatuses[*]}{.name}{"\trestarts="}{.restartCount}{"\tlast_reason="}{.lastState.terminated.reason}{"\texit="}{.lastState.terminated.exitCode}{"\tfinished="}{.lastState.terminated.finishedAt}{"\tnow_waiting="}{.state.waiting.reason}{"\n"}{end}'
  section "1. MinIO / 전처리기 컨테이너 종료 사유"
  for p in $minio_pods $prep_pods; do
    local node
    node=$($K -n "$NS" get "$p" -o jsonpath='{.spec.nodeName}' 2>/dev/null)
    echo "$p (node=$node)" >> "$SUMMARY"
    $K -n "$NS" get "$p" -o jsonpath="$JP" 2>&1 | sed 's/^/    /' >> "$SUMMARY"
  done

  # 2. 리소스 limit / probe
  for p in $minio_pods $prep_pods; do
    run 02_resources_probes.txt "$K -n $NS get $p -o jsonpath='{range .spec.containers[*]}{.name}{\"\n  resources: \"}{.resources}{\"\n  liveness: \"}{.livenessProbe}{\"\n  readiness: \"}{.readinessProbe}{\"\n\"}{end}'"
  done
  section "2. MinIO 메모리 limit"
  for p in $minio_pods; do
    echo "$p limit=$($K -n "$NS" get "$p" -o jsonpath='{.spec.containers[0].resources.limits.memory}' 2>/dev/null) request=$($K -n "$NS" get "$p" -o jsonpath='{.spec.containers[0].resources.requests.memory}' 2>/dev/null)" >> "$SUMMARY"
  done

  # 3. PVC -> PV -> NFS 경로
  section "3. MinIO 스토리지 (PVC -> PV -> NFS)"
  local pv_list=""
  for p in $minio_pods; do
    for pvc in $($K -n "$NS" get "$p" -o jsonpath='{.spec.volumes[*].persistentVolumeClaim.claimName}' 2>/dev/null); do
      local pv
      pv=$($K -n "$NS" get pvc "$pvc" -o jsonpath='{.spec.volumeName}' 2>/dev/null)
      pv_list="$pv_list $pv"
      echo "pvc=$pvc pv=$pv $($K get pv "$pv" -o jsonpath='sc={.spec.storageClassName} nfs={.spec.nfs.server}:{.spec.nfs.path} csi={.spec.csi.driver} {.spec.csi.volumeAttributes}' 2>/dev/null)" >> "$SUMMARY"
    done
  done

  # 같은 NFS 서버를 쓰는 다른 PV (같이 죽을 수 있는 대상)
  run 03_pv_nfs_all.txt "$K get pv -o custom-columns=PV:.metadata.name,SC:.spec.storageClassName,CLAIM:.spec.claimRef.namespace/.spec.claimRef.name,NFS_SERVER:.spec.nfs.server,NFS_PATH:.spec.nfs.path"

  # 4. 같은 시간대에 함께 죽은 파드 (전 네임스페이스, 종료 시각순)
  section "4. 최근 종료 이력이 있는 컨테이너 (종료 시각순, 상위 40)"
  $K get pod -A -o json 2>/dev/null | python3 -c '
import json,sys
rows=[]
for p in json.load(sys.stdin)["items"]:
    for c in p["status"].get("containerStatuses",[]) or []:
        t=(c.get("lastState") or {}).get("terminated")
        if t:
            rows.append((t.get("finishedAt",""),p["metadata"]["namespace"],p["metadata"]["name"],c["name"],t.get("reason",""),t.get("exitCode",""),c.get("restartCount",0),p["spec"].get("nodeName","")))
for r in sorted(rows,reverse=True)[:40]:
    print("%s  %-14s %-55s %-20s %-10s exit=%-4s restarts=%-4s node=%s"%r)
' >> "$SUMMARY" 2>&1

  # 5. 이벤트
  run 05_events.txt "$K -n $NS get events --sort-by=.lastTimestamp | grep -iE 'minio|preprocess|Unhealthy|OOM|Killing|BackOff|FailedMount|Evict|NodeNotReady' | tail -100"
  run 05_events.txt "$K get events -A --sort-by=.lastTimestamp | grep -iE 'OOM|FailedMount|NodeNotReady|Evict' | tail -50"

  # 6. 로그 (previous = 죽기 직전)
  local LOG_PAT='error|timeout|timed out|disk|drive|offline|i/o|stale|panic|fatal|memory|killed|connection refused|unavailable'
  for p in $minio_pods $prep_pods; do
    local n="${p#pod/}"
    run "06_logs_${n}.txt" "$K -n $NS logs $p --all-containers --previous --tail=$LOG_TAIL 2>&1 | grep -iE '$LOG_PAT' | tail -100"
    run "06_logs_${n}.txt" "$K -n $NS logs $p --all-containers --since=$SINCE --tail=2000 2>&1 | grep -iE '$LOG_PAT' | tail -100"
  done

  # 7. preprocess-api 단계별 소요시간 (SAMSUNGCARD-405: get_file_meta 가 큰 파일 전체를 읽어 MD5 계산)
  for d in $($K -n "$NS" get deploy -o name 2>/dev/null | grep -i "preprocess-api"); do
    run 07_preprocess_timer.txt "$K -n $NS logs $d --all-containers --since=$SINCE --tail=20000 2>&1 | grep -E '\[Timer\]' | grep -E 'validate_file|get_file_meta|get_request' | tail -200"
  done

  # 8. 노드 상태 / 현재 사용량
  local nodes
  nodes=$(for p in $minio_pods $prep_pods; do $K -n "$NS" get "$p" -o jsonpath='{.spec.nodeName}{"\n"}' 2>/dev/null; done | sort -u)
  for n in $nodes; do
    run 08_nodes.txt "$K get node $n -o jsonpath='{range .status.conditions[*]}{.type}={.status} ({.reason}) {.lastTransitionTime}{\"\n\"}{end}'"
  done
  run 08_nodes.txt "$K -n $NS top pod 2>&1 | grep -iE 'NAME|minio|preprocess'"
  run 08_nodes.txt "$K top node"

  # 9. Prometheus (선택)
  if [ -n "$PROM_URL" ]; then
    prom_check
  else
    section "9. Prometheus"
    echo "생략 (-p http://<prometheus>:9090 지정 시 메모리/iowait 추이 조회)" >> "$SUMMARY"
  fi

  # 노드 점검 안내
  section "다음 단계: MinIO 노드에서 NAS 점검"
  for p in $minio_pods; do
    echo "node=$($K -n "$NS" get "$p" -o jsonpath='{.spec.nodeName}' 2>/dev/null)" >> "$SUMMARY"
  done
  for pv in $pv_list; do
    echo "  sudo ./$(basename "$0") node -v $pv -f \"<장애시각-1h>\" -u \"<장애시각+1h>\"" >> "$SUMMARY"
  done
}

prom_check() {
  section "9. Prometheus (최근 $SINCE, 최대값)"
  local end start step=60
  end=$(date +%s); start=$(( end - $(since_to_sec "$SINCE") ))
  local -a names=(minio_mem_working_set minio_mem_limit preprocess_mem_working_set node_iowait_ratio node_procs_blocked)
  local -a queries=(
    "max by (pod) (container_memory_working_set_bytes{namespace=\"$NS\",pod=~\".*minio.*\",container!=\"\"})"
    "max by (pod) (kube_pod_container_resource_limits{namespace=\"$NS\",pod=~\".*minio.*\",resource=\"memory\"})"
    "max by (pod) (container_memory_working_set_bytes{namespace=\"$NS\",pod=~\".*preprocess.*\",container!=\"\"})"
    "avg by (instance) (rate(node_cpu_seconds_total{mode=\"iowait\"}[5m]))"
    "max by (instance) (node_procs_blocked)"
  )
  local i
  for i in "${!names[@]}"; do
    local f="$OUT/09_prom_${names[$i]}.json"
    timeout "$CMD_TIMEOUT" curl -sk -G "$PROM_URL/api/v1/query_range" \
      --data-urlencode "query=${queries[$i]}" --data-urlencode "start=$start" \
      --data-urlencode "end=$end" --data-urlencode "step=$step" -o "$f"
    python3 - "$f" "${names[$i]}" >> "$SUMMARY" 2>&1 <<'PY'
import json,sys,datetime
f,name=sys.argv[1],sys.argv[2]
try: d=json.load(open(f))
except Exception as e: print(f"{name}: 조회 실패 ({e})"); sys.exit()
res=d.get("data",{}).get("result",[])
if not res: print(f"{name}: 데이터 없음"); sys.exit()
for r in res:
    vals=[(float(v),int(t)) for t,v in r["values"] if v not in ("NaN","+Inf")]
    if not vals: continue
    mx,t=max(vals)
    label=r["metric"].get("pod") or r["metric"].get("instance") or ""
    shown=f"{mx/1048576:.0f}Mi" if "mem" in name else f"{mx:.3f}"
    print(f"{name:28s} {label:55s} max={shown} at {datetime.datetime.fromtimestamp(t)}")
PY
  done
}

# ---------------------------------------------------------------- node
node_check() {
  [ -z "$PV_NAME" ] && { echo "-v <PV이름> 필요 (cluster 점검 결과 3번 항목 참조)"; exit 1; }
  [ "$(id -u)" -ne 0 ] && note "!! root 아님: dmesg/journalctl 일부가 보이지 않을 수 있음 (sudo 권장)"

  note "[node] host=$(hostname) pv=$PV_NAME"
  note "결과 디렉터리: $OUT"

  # 1. PV 마운트 위치
  section "1. NFS 마운트"
  local mnts
  mnts=$(awk -v pv="$PV_NAME" '$2 ~ pv && $3 ~ /^nfs/ {print $2}' /proc/mounts | sort -u)
  if [ -z "$mnts" ]; then
    echo "!! 이 노드에 $PV_NAME NFS 마운트 없음 (MinIO가 다른 노드로 옮겨졌는지 확인)" >> "$SUMMARY"
  fi
  awk -v pv="$PV_NAME" '$2 ~ pv && $3 ~ /^nfs/' /proc/mounts >> "$SUMMARY"
  run 01_nfs_mounts_all.txt "grep -E ' nfs4? ' /proc/mounts"

  # 2. NFS 응답 시간 실측
  section "2. NFS 응답 시간 (상한 ${NFS_PROBE_TIMEOUT}s, ${NFS_SLOW_SEC}s 이상이면 지연)"
  local m
  for m in $mnts; do
    local t0 t1 rc el
    t0=$(date +%s.%N); timeout "$NFS_PROBE_TIMEOUT" stat -f "$m" >/dev/null 2>&1; rc=$?; t1=$(date +%s.%N)
    el=$(python3 -c "print(f'{$t1-$t0:.2f}')")
    echo "stat -f  $m : ${el}s rc=$rc $( [ $rc -eq 124 ] && echo '<< TIMEOUT: NAS hang 의심' )" >> "$SUMMARY"
    t0=$(date +%s.%N); timeout "$NFS_PROBE_TIMEOUT" ls "$m" >/dev/null 2>&1; rc=$?; t1=$(date +%s.%N)
    el=$(python3 -c "print(f'{$t1-$t0:.2f}')")
    echo "ls       $m : ${el}s rc=$rc $( [ $rc -eq 124 ] && echo '<< TIMEOUT: NAS hang 의심' )" >> "$SUMMARY"
  done

  # 3. 커널 NFS / hung task 메시지
  local KPAT='nfs: server .* not (responding|OK)|nfs.*stale|hung_task|blocked for more than|rpc.*timed out|Out of memory|oom-kill|Killed process'
  section "3. 커널 메시지 (NFS 지연 / hung task / OOM)"
  dmesg -T 2>/dev/null | grep -iE "$KPAT" | tail -40 >> "$SUMMARY"
  if command -v journalctl >/dev/null; then
    local jargs="-k --no-pager"
    [ -n "$J_FROM" ] && jargs="$jargs --since \"$J_FROM\""
    [ -n "$J_UNTIL" ] && jargs="$jargs --until \"$J_UNTIL\""
    run 03_journal_kernel.txt "journalctl $jargs | grep -iE '$KPAT' | tail -300"
  fi

  # 4. D-state 프로세스 (I/O 대기로 묶인 프로세스)
  section "4. D-state 프로세스 (minio / python / gunicorn 이 보이면 NAS hang)"
  ps -eo pid,stat,etime,wchan:32,comm,args --no-headers 2>/dev/null | awk '$2 ~ /^D/' | cut -c1-200 >> "$SUMMARY"

  # 5. NFS 커널 스레드 CPU (KOGAS-21: '<ip>-manager' 스레드 CPU 100% retry loop)
  section "5. NFS/RPC 커널 스레드 CPU"
  ps -eo pid,stat,pcpu,etime,comm --sort=-pcpu --no-headers 2>/dev/null | grep -E 'nfs|rpciod|-ma(nager)?$' | head -15 >> "$SUMMARY"

  # 6. NFS RPC 통계 (retrans, 평균 응답시간)
  for m in $mnts; do
    if command -v nfsiostat >/dev/null; then
      run 06_nfsiostat.txt "nfsiostat 2 3 $m"
    fi
    awk -v m="$m" '$0 ~ "mounted on "m" " {p=1} p && /^device / && $0 !~ "mounted on "m" " {p=0} p' /proc/self/mountstats >> "$OUT/06_mountstats.txt" 2>&1
  done
  section "6. NFS RPC 요약 (READ/WRITE: ops trans timeouts ... ; 'xprt' 의 bad_xids/retrans)"
  grep -E '^\s+(READ|WRITE|GETATTR|LOOKUP):|xprt:' "$OUT/06_mountstats.txt" 2>/dev/null >> "$SUMMARY"

  # 7. 노드 I/O 대기
  section "7. vmstat (b=I/O 대기 프로세스 수, wa=iowait%)"
  timeout 15 vmstat 1 5 >> "$SUMMARY" 2>&1
  run 07_free.txt "free -m; uptime"
}

case "$MODE" in
  cluster) cluster_check ;;
  node)    node_check ;;
esac

section "판정 기준"
cat >> "$SUMMARY" <<'EOF'
- MinIO last_reason=OOMKilled(exit 137) + 메모리가 limit 근처, NFS 정상   -> MinIO 메모리 부족 (limit 1Gi 이상)
- NFS stat/ls TIMEOUT, 'nfs: server not responding', D-state, probe 실패 -> NAS 지연/hang 으로 MinIO·전처리기 동반 정지
- NFS 정상, 전처리기만 OOMKilled/probe 실패                              -> 전처리기 단독 원인 (KOGAS-63, SAMSUNGCARD-405)
- 같은 시각 NAS 백업 등 대량 작업 존재                                    -> 고객사 작업 이력 확인 (KOGAS-21 사례)
EOF

tar czf "${OUT}.tar.gz" "$OUT" 2>/dev/null
echo
cat "$SUMMARY"
echo
echo "결과: $OUT/  (묶음: ${OUT}.tar.gz)"
