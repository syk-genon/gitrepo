# GenOS Kubernetes 업그레이드 절차서 (전면 정지 방식)

작성일: 2026-09-08
대상: `dl-prod-mst-301` (kubespray, k8s v1.28.14, 마스터 3대)
근거: `산출물/k8s_1.28→1.35_업그레이드_영향분석.md`
방식: **전 워크로드 `replicas: 0` → 버전 상향 → 복원** (계획된 전면 다운타임)

> 이 방식은 파드 이동(evict/drain) 중 생기는 문제를 원천 제거한다.
> Galera 쿼럼 손실, 사이드카 전수 재시작, serving grace 4시간, PDB 부재가 모두 무의미해진다.
> 대신 **노드·클러스터 인프라 문제와 업그레이드 후 필요한 것들은 그대로 남는다**(§1, §6).

---

## 0. 목표 버전 결정 — 먼저 정할 것

| 목표 | 단계 | Calico | Istio | 난이도 |
|---|---|---|---|---|
| **1.30** | 2단계 | v3.26.4 유지 가능 | 1.22.3 유지 가능 | 낮음 |
| **1.35** | 7단계 | **v3.32 상향 필수** (6단계) | **1.29 상향 필수** (7단계) | 높음 |

1.31부터 Calico·Istio가 지원 범위를 벗어난다. **1.30을 1차 목표로 두고, 거기서 재평가**하는 것을 권한다.
본 절차서는 1.30까지를 본문으로 하고, 1.31 이후는 §7에 별도로 둔다.

---

## 1. D-30 ~ D-7 : 선결 확인

**하나라도 막히면 일정을 다시 잡는다.** 순서대로 확인한다.

### 1.1 노드 cgroup 버전 — 최우선

```bash
for h in $(kubectl get nodes -o name | sed 's|node/||'); do
  printf '%-24s ' "$h"
  ssh "$h" 'stat -fc %T /sys/fs/cgroup'
done
```

| 결과 | 판정 |
|---|---|
| 전 노드 `cgroup2fs` | 진행 가능 |
| 하나라도 `tmpfs` | **1.35 불가.** 노드 OS 작업 선행 필요 → GPU 노드는 드라이버 재설치 동반 |

1.30까지만 갈 경우 cgroup v1도 동작하나, 어차피 확인해 두어야 이후 계획이 선다.

### 1.2 인증서 만료 — 다단계 창을 쓸 때 필수

kubespray 기본 인증서 수명은 1년이다. 며칠에 걸쳐 올리는 중 만료되면 복구가 매우 번거롭다.

```bash
kubeadm certs check-expiration
# 또는 마스터에서
for f in apiserver apiserver-kubelet-client front-proxy-client; do
  printf '%-28s ' "$f"
  openssl x509 -in /etc/kubernetes/ssl/$f.crt -noout -enddate
done
```

남은 기간이 **60일 미만이면 갱신 후** 업그레이드에 착수한다.

### 1.3 nfs-provisioner — 업그레이드 후 신규 생성을 좌우

현행 `v4.0.2`(2021년, client-go k8s 1.20 세대). 업그레이드 중에는 문제없으나(기존 PVC 는 이미 바인딩됨),
**올린 뒤 새 PVC 생성이 막히면** 신규 codespace·serving·전처리기 배포가 전부 실패한다.

```bash
kubectl -n llmops get deploy nfs-client-provisioner \
  -o jsonpath='{.spec.template.spec.containers[0].image}'
```

→ **v4.0.18 이상으로 상향 후 신규 PVC 생성 테스트까지 마칠 것.** 별도 작업으로 선행한다.

### 1.4 GPU Operator 의 k8s 지원 범위

device-plugin `v0.17.4` 확인됨. Operator 자체 버전과 목표 k8s 지원 여부를 확인한다.

```bash
kubectl -n gpu-operator get clusterpolicy -o yaml | grep -iE 'version|operator'
helm list -n gpu-operator
```

containerd 를 1.7 로 유지하면 runtime 재구성은 불필요하다. 확인할 것은 **plugin/Operator 의 k8s 버전 지원**뿐이다.

### 1.5 kubectl / CI 준비

- bastion, Jenkins 에이전트의 kubectl 은 클러스터 대비 **±1 마이너**만 지원된다. 단계마다 교체한다.
- `scripts/restart/*.sh` 57개가 `kubectl rollout restart` 를 호출한다. 업그레이드 창 동안 CI 파이프라인을 **중지**한다.

### 1.6 외부 인그레스 경로 확인

`istio-ingressgateway` 가 `type=ClusterIP` 인데 외부 접속이 된다. 앞단 L4/L7 프록시가 GenOS 형상 밖에 있다.
**인프라팀에 구성을 확인하고 문서화한다.** 1.30 까지는 Istio 를 건드리지 않으므로 영향이 없지만, 그 이후에는 필수다.

### 1.7 백업 체계 배포 — 롤백 안전망

`llmops-backup-runner` SA 가 운영에 없다(= 백업 CronJob 미배포). 되돌리기 어려운 작업을 안전망 없이 하게 된다.

```bash
kubectl -n llmops get sa    # llmops-backup-runner 가 있는지
```

→ `backup/k8s/` 배포 후 `backup/scripts/restore_test.sh` 로 **복구 리허설까지** 마칠 것.

---

## 2. D-1 : 선행 조치

### 2.1 Galera grace 연장 — 이 방식의 핵심

`terminationGracePeriodSeconds` 가 **30초**다. MariaDB 가 버퍼 풀 flush 하는 데 부족해
SIGKILL → unclean shutdown → `safe_to_bootstrap: 0` → **자동 복구 불가**로 이어진다.

```bash
kubectl -n llmops patch sts mariadb-mariadb-galera \
  -p '{"spec":{"template":{"spec":{"terminationGracePeriodSeconds":300}}}}'
```

patch 후 파드가 롤링 재시작되므로, **정지 당일이 아니라 하루 전에** 적용하고 클러스터 정상을 확인한다.
Weaviate 는 이미 600초라 조정 불필요.

### 2.2 현재 레플리카 수 저장 — 복원의 근거

95건이고 수가 제각각이다(flowise-300 = 15, 2 레플리카 10종, 나머지 1).

```bash
mkdir -p ~/upgrade-state && cd ~/upgrade-state
kubectl -n llmops get deploy -o custom-columns=NAME:.metadata.name,REP:.spec.replicas --no-headers > deploy-replicas.txt
kubectl -n llmops get sts    -o custom-columns=NAME:.metadata.name,REP:.spec.replicas --no-headers > sts-replicas.txt
wc -l deploy-replicas.txt sts-replicas.txt    # 93 / 2 예상
```

### 2.3 전체 형상 스냅샷

```bash
python3 k8s-manifests/sync_live_to_template.py   # 운영 실물 추출
kubectl get all -A -o yaml > ~/upgrade-state/all-resources.yaml
kubectl -n istio-system get svc istio-ingressgateway -o yaml > ~/upgrade-state/ingressgw.yaml
kubectl -n istio-system get cm istio -o yaml > ~/upgrade-state/istio-configmap.yaml
```

### 2.4 백업

```bash
# 애플리케이션 데이터
bash backup/scripts/run_backup.sh

# etcd (마스터에서)
ETCDCTL_API=3 etcdctl \
  --endpoints=https://172.16.27.61:2379 \
  --cacert=/etc/ssl/etcd/ssl/ca.pem \
  --cert=/etc/ssl/etcd/ssl/node-dl-prod-mst-301.pem \
  --key=/etc/ssl/etcd/ssl/node-dl-prod-mst-301-key.pem \
  snapshot save /backup/etcd-$(date +%Y%m%d).db
```

---

## 3. Phase A : 내리기 (앱 → DB 순서)

**순서를 지킨다.** DB 를 먼저 내리면 앱들이 커넥션 에러로 CrashLoop 돌며 지저분하게 종료된다.

### A-1. 애플리케이션 (DB·MaxScale 제외 전부)

```bash
cd ~/upgrade-state
# 아래 목록을 뺀 나머지 Deployment 를 0으로
EXCLUDE='maxscale|nfs-client-provisioner'
awk '{print $1}' deploy-replicas.txt | grep -vE "$EXCLUDE" | \
  xargs -I{} kubectl -n llmops scale deploy {} --replicas=0

kubectl -n llmops get pods --no-headers | wc -l   # 줄어드는지 확인
```

### A-2. MaxScale

```bash
kubectl -n llmops scale deploy maxscale --replicas=0
```

### A-3. Weaviate → Galera (STS, 역순 자동 종료)

```bash
kubectl -n llmops scale sts weaviate --replicas=0
kubectl -n llmops wait --for=delete pod -l app=weaviate --timeout=900s

kubectl -n llmops scale sts mariadb-mariadb-galera --replicas=0
kubectl -n llmops wait --for=delete pod -l app.kubernetes.io/name=mariadb-galera --timeout=900s
```

> 라벨 셀렉터는 실제 값 확인 후 사용할 것 — `kubectl -n llmops get sts mariadb-mariadb-galera -o jsonpath='{.spec.selector}'`

**A-3 검증 (중요)**: StatefulSet 은 역순(2→1→0)으로 종료되고, 마지막 파드가 `safe_to_bootstrap: 1` 을 남긴다.
grace 300초 내에 정상 종료되었는지 로그로 확인한다.

```bash
kubectl -n llmops logs mariadb-mariadb-galera-0 --previous | tail -30
# "Shutdown complete" 류가 보여야 정상. SIGKILL 흔적이면 §5 참조
```

### A-4. 잔여 확인

```bash
kubectl -n llmops get pods    # DaemonSet 소속 외 파드가 없어야 함
```

> DaemonSet(calico-node, kube-proxy, nvidia-*, fluentd, node-exporter)은 내리지 않는다. 노드와 함께 갱신된다.

---

## 4. Phase B : 버전 상향 (1단계씩)

각 마이너마다 아래를 반복한다. **한 번에 여러 단계를 몰아서 올리지 않는다.**

```bash
# kubespray (인벤토리 위치는 환경에 맞게)
ansible-playbook -i inventory/genos/hosts.yaml upgrade-cluster.yml \
  -e kube_version=v1.29.x
```

각 단계 후:

```bash
kubectl get nodes                          # 전 노드 Ready, VERSION 확인
kubectl -n kube-system get pods            # 컨트롤플레인·CoreDNS·calico 정상
kubectl get --raw /healthz
```

**단계 사이에 etcd 스냅샷을 다시 뜬다.**

### 체크포인트

| 시점 | 할 일 |
|---|---|
| **1.29 완료** | Phase C 로 한 번 올려 스모크 테스트 → 다시 Phase A |
| **1.30 완료** | Phase C 전체 복원 + 전체 검증. **여기서 계속 갈지 재평가**(§7) |

전 구간을 내려둔 채 7단계를 쭉 올리면 어디서 깨졌는지 알 수 없다. 최소 위 두 지점에서는 올려서 확인한다.

---

## 5. Phase C : 올리기 (DB → 앱 순서)

### C-1. Galera

```bash
cd ~/upgrade-state
grep mariadb sts-replicas.txt        # 원래 3
kubectl -n llmops scale sts mariadb-mariadb-galera --replicas=3
kubectl -n llmops rollout status sts/mariadb-mariadb-galera --timeout=1800s
```

**반드시 확인하고 다음으로 넘어간다.**

```bash
kubectl -n llmops exec mariadb-mariadb-galera-0 -- \
  mysql -uroot -p"$MARIADB_ROOT_PW" -e \
  "SHOW STATUS LIKE 'wsrep_cluster_size'; SHOW STATUS LIKE 'wsrep_cluster_status';"
```

| 결과 | 판정 |
|---|---|
| `wsrep_cluster_size = 3`, `wsrep_cluster_status = Primary` | 정상. 다음 단계 |
| size < 3 | 파드 로그 확인. SST 진행 중이면 대기 |
| 파드가 CrashLoop / `safe_to_bootstrap` 오류 | **아래 수동 복구** |

#### Galera 수동 복구 (자동 부트스트랩 실패 시)

```bash
# 1) 각 파드에서 실제 seqno 확인 (파드가 안 뜨면 임시 파드로 PVC 마운트)
kubectl -n llmops exec mariadb-mariadb-galera-N -- \
  cat /bitnami/mariadb/data/grastate.dat

# 2) seqno 가 가장 큰 노드를 고른다 (-1 이면 mysqld --wsrep-recover 로 확인)
# 3) 그 노드의 grastate.dat 을 safe_to_bootstrap: 1 로 수정
# 4) 해당 파드만 부트스트랩 모드로 기동 후 나머지 합류
```

Bitnami 차트를 쓰는 경우 `galera.bootstrap.forceSafeToBootstrap=true` 옵션이 있다. **차트 버전별 동작이 다르므로 사전 확인 필요.**

### C-2. Weaviate

```bash
kubectl -n llmops scale sts weaviate --replicas=3
kubectl -n llmops rollout status sts/weaviate --timeout=1800s
# 스키마·객체 조회로 데이터 확인
```

### C-3. MaxScale

Galera 가 Primary 가 되기 **전에** 올리면 전 서버를 down 으로 마킹한다. 반드시 C-1 검증 후.

```bash
kubectl -n llmops scale deploy maxscale --replicas=2
```

### C-4. 애플리케이션 복원

```bash
cd ~/upgrade-state
while read -r name rep; do
  kubectl -n llmops scale deploy "$name" --replicas="$rep"
done < deploy-replicas.txt

kubectl -n llmops get deploy -o custom-columns=NAME:.metadata.name,REP:.spec.replicas --no-headers \
  | diff - deploy-replicas.txt && echo "레플리카 수 일치"
```

> 95개가 동시에 `imagePullPolicy: Always` 로 harbor 를 때린다. harbor 가용성과 부하를 지켜본다.

---

## 6. Phase D : 검증

순서대로 확인한다. 실패 시 다음으로 넘어가지 않는다.

| # | 항목 | 확인 |
|---|---|---|
| 1 | 노드 | `kubectl get nodes` 전부 Ready, 버전 일치 |
| 2 | 파드 | `kubectl -n llmops get pods \| grep -v Running` 이 비어야 함 |
| 3 | **Galera** | `wsrep_cluster_size=3`, `Primary` |
| 4 | **Weaviate** | 3 파드 Ready, 스키마·객체 조회 |
| 5 | 로그인 | admin-front / app-front |
| 6 | **채팅 웹소켓** | 연결 및 스트리밍 응답 |
| 7 | 서빙 | 기존 리비전 추론 응답 |
| 8 | **신규 PVC** | codespace 신규 생성 → nfs-provisioner 동작 확인 (§1.3) |
| 9 | GPU | GPU 파드 기동 + 디바이스 인식 (`nvidia-smi`) |
| 10 | flowise | 접근 및 인증 |
| 11 | 배치 | 인사 싱크 CronJob 수동 트리거 |
| 12 | 외부 접속 | 인그레스 경로 정상 |
| 13 | 관측 | Prometheus/Grafana 수집 재개, ES 로그 유입량 정상 |
| 14 | **백업** | 1회 실행 및 복구 검증 |

---

## 7. 1.31 이후로 갈 경우 (추가 작업)

1.30 까지는 Calico·Istio·containerd 를 건드리지 않는다. **1.31부터는 다르다.**

### 7.1 순서 원칙

컴포넌트를 **"현행 k8s 와 목표 k8s 를 동시에 지원하는 버전"으로 먼저 올린 뒤** k8s 를 올린다.

```
Calico 상향 → Istio 상향 → k8s 1단계 → 검증   (반복)
```

| Istio | 지원 k8s |
|---|---|
| 1.22 (현재) | 1.27 – 1.30 |
| 1.24 | 1.28 – 1.31 |
| 1.28 | 1.30 – 1.34 |
| 1.29 | 1.31 – 1.35 |

Calico 는 v3.26.4 → **v3.32** (6단계), Istio 는 1.22 → **1.29** (7단계). 둘 다 마이너 스킵 불가.

### 7.2 Istio 업그레이드 시 반드시 확인

앱이 0 이라 사이드카 문제는 없으나, 아래는 그대로 남는다.

1. **mesh configmap 덮어쓰기** — `istioctl`/`helm` 이 `istio` configmap 을 재렌더링하면
   `extensionProviders`(ext_authz `llmops-admin-api-service`)가 사라진다.
   → codespace·flowise 인증이 **fail-closed** 로 막힌다. §2.3 스냅샷으로 매 단계 대조·복원.
2. **EnvoyFilter** `llmops/llmops-flowise-auth` — 리스너 매칭 실패가 **오류 없이** 발생한다. 기능 검증 필수.
3. **외부 프록시** — ingressgateway 파드 IP/셀렉터가 바뀌면 앞단 프록시도 갱신(§1.6).
4. **CRD 버전** — `networking.istio.io/v1alpha3` 25건, `security.istio.io/v1beta1` 2건.
   orchestrator 는 `ISTIO_VERSION` 환경변수로 결정되므로 configmap 수정만으로 이관 가능.

### 7.3 containerd

1.35 가 containerd 1.x 를 지원하는 **마지막 버전**이다. 1.7 유지로 1.35 까지 갈 수 있다.
단 1.36 이후에는 2.x 필수이며, 그때 GPU Operator 의 containerd 설정 재작성이 동반된다.

---

## 8. 롤백

| 시점 | 방법 |
|---|---|
| Phase A 중 | 레플리카 복원만 하면 됨 (§5) |
| Phase B 중 (k8s 업그레이드 실패) | etcd 스냅샷 복구 + kubespray 이전 버전 재적용. **마이너 다운그레이드는 공식 지원되지 않음** — 스냅샷 복구가 실질적 유일 수단 |
| Phase C 중 (Galera 미기동) | §5 수동 복구 → 실패 시 `backup/scripts/restore_test.sh` 기반 논리 복원 |

**마이너 다운그레이드가 안 된다는 점이 이 작업의 본질적 위험이다.** 단계마다 etcd 스냅샷을 남기는 이유가 이것이다.

---

## 9. 미확정 / 확인 후 확정할 항목

| 항목 | 확인 방법 |
|---|---|
| 노드 cgroup 버전 | §1.1 |
| 인증서 잔여 기간 | §1.2 |
| Galera StatefulSet 라벨 셀렉터 | `kubectl -n llmops get sts mariadb-mariadb-galera -o jsonpath='{.spec.selector}'` |
| Galera 차트 종류·버전 (부트스트랩 동작) | `helm list -n llmops` |
| Galera 데이터 경로 (`grastate.dat` 위치) | 차트에 따라 `/bitnami/mariadb/data` 또는 `/var/lib/mysql` |
| GPU Operator 버전 | §1.4 |
| kubespray 인벤토리 위치 | 운영 담당 |
| 외부 인그레스 프록시 구성 | §1.6 |
| 다운타임 허용 창 | 1.30 = 2단계, 1.35 = 7단계. 단계당 수 시간 |

---

## 10. 한 장 요약

```
[D-30] cgroup 확인 → 인증서 확인 → nfs-provisioner 상향 → GPU Operator 확인 → 백업 배포
[D-1]  Galera grace 300초 → 레플리카 수 저장 → 형상 스냅샷 → 백업 + etcd 스냅샷
[D-day]
  A. 내리기   앱 → MaxScale → Weaviate → Galera   (역순 자동 종료 / 정상종료 로그 확인)
  B. 올리기   k8s 1단계씩. 매 단계 etcd 스냅샷. 1.29·1.30 에서 스모크 테스트
  C. 복원     Galera → (Primary 확인) → Weaviate → MaxScale → 앱
  D. 검증     14개 항목. 특히 신규 PVC 생성과 GPU 디바이스 인식
[1.30 도달] 재평가 — 더 갈지, Calico·Istio 상향을 감당할지
```
