# GenOS 외부 API 호출 가능 항목 정리

> 기준: `bok-develop` 브랜치 코드 (2026-10-23)
> 근거: `gateway-api/src/main.py`, `gateway-api/src/filters/auth/authkey.py`, `admin-api/src/service/auth/async_/authkey_constraint.py`, `admin-api/src/util/k8s_resource_utils.py`, `k8s-manifests/istio/virtualservices/llmops-api-virtualservice.yaml`, `admin-front/src/data/guide.js`

## 1. 결론

외부 사용자가 **GenOS 발급 인증키(Bearer)** 로 호출할 수 있는 API는 `gateway-api`를 통하는 **2종(서빙, 워크플로우)** 뿐이다.
인증키 리소스 타입도 `serving`, `workflow` 두 가지만 존재한다 (`AuthKeyResourceType`).

| 구분 | 외부 URL | 게이트웨이 내부 경로 | 대상 컨테이너 | 가드레일 |
|---|---|---|---|---|
| 서빙 (대표 리비전) | `/api/gateway/rep/serving/{serving_id}/...` | `/rep/serving/{serving_id}/...` | `serving-{id}-{rev}:8080` (가중치 라우팅) | 적용 |
| 서빙 (특정 리비전) | `/api/gateway/serving/{serving_id}/{revision_id}/...` | `/serving/{id}/{rev}/...` | `serving-{id}-{rev}:8080` | 미적용 |
| 워크플로우 | `/api/gateway/workflow/{workflow_id}/...` | `/workflow/{id}/...` | `workflow-{id}:8080` | 적용 |

- 서빙 경로는 정적 manifest가 아니라 **서빙 배포 시 admin-api/orchestrator가 VirtualService를 동적 생성**한다. (정적 `/api/gateway/serving/` 노출은 #1406에서 주석 처리)
- 워크플로우는 정적 VirtualService(`/api/gateway/workflow/`)로 노출되며, 배포 시에도 별도 라우트가 생성된다.
- 이스티오가 `x-genos-is-external: true` 헤더를 붙여 넘기므로 외부 요청은 반드시 인증키 검증을 거친다 (헤더 없으면 클러스터 내부 요청으로 간주해 인증 생략).

## 2. 서빙 API (LLM / 임베딩 / 리랭커)

OpenAI 호환(vLLM) 엔드포인트를 그대로 프록시한다.

| Method | Path (base 이후) | 용도 |
|---|---|---|
| GET | `/v1/models` | 모델 ID 조회 |
| POST | `/v1/chat/completions` | 채팅 생성 (`stream: true` 지원, SSE) |
| POST | `/v1/completions` | 텍스트 생성 (vLLM 지원 시) |
| POST | `/v1/embeddings` | 임베딩 |
| POST | `/v1/rerank` | 리랭크 |
| POST | `/run` | HuggingFace 형식 임베딩 요청 → `/v1/embeddings`로 자동 변환 |

- `/v1` 생략 호환: `/chat/completions`, `/embeddings`, `/models`, `/rerank` 는 `/v1/...`로 자동 매핑 (`OPENAI_COMPATIBLE_ROUTES` configmap).
- 게이트웨이는 모든 HTTP 메서드/하위 경로를 통과시키므로, 컨테이너(vLLM 등)가 제공하는 나머지 엔드포인트도 기술적으로는 호출 가능하다 (공식 가이드 범위는 위 표).
- 서빙 유형별 동작
  - 일반 vLLM 서빙: 요청 body의 `model` 값을 리비전 ID로 자동 치환 (`x-genos-body-model`)
  - 외부 API 서빙(#1406, 예: NCloud HCX/OpenAI 등록): 게이트웨이가 등록된 외부 URI로 대신 호출, 필요한 헤더/바디/파라미터를 주입
  - sLoRA 서빙(#3857): 베이스 서빙 리비전으로 라우팅 + 어댑터 model 주입

## 3. 워크플로우 API

| Method | Path (base 이후) | 용도 |
|---|---|---|
| GET | `/healthcheck` | 인증키·연결 확인 |
| POST | `/run/v2` | 워크플로우 실행 (공식 가이드 기준). body: `question`, `stream`, `chatId` 등 |
| POST | `/run/` | v1 실행 (`data`, `sid`, `chat_request_id`). 내부(채팅 화면)용 레거시 |

- 스트리밍: `stream: true` → 라인 단위 `token: ...` / 최종 `result: {...}`
- 응답 형식: `{code, errMsg, data: {question, text, sourceDocuments, chatId, chatMessageId, sessionId}}`

## 4. 공통 요청 규약

| 헤더 | 필수 | 설명 |
|---|---|---|
| `Authorization: Bearer <인증키>` | O | 해당 서빙/워크플로우 ID에 발급된 키만 유효 |
| `x-genos-user-id` | X | 이용 로그에 사용자 표시 |
| `x-genos-trace-id` | X | 요청 묶음 추적 (uuid4) |
| `x-genos-session-id` + body `chatId` | X | 워크플로우 멀티턴 대화 |

## 5. 인증키 정책 (`AuthKeyBearer` 필터)

| 항목 | 동작 | 실패 응답 |
|---|---|---|
| 토큰 검증 | 리소스 타입 + 리소스 ID + 토큰 + 활성 여부 일치 | 401 `Invalid token` / `Bearer token required` |
| 허용 IP | `allowed_ip`(콤마 구분) 설정 시 `X-Forwarded-For` 첫 IP 비교 | 401 `Invalid IP address` |
| 만료일 | `expiry_date` 경과 시 차단 | 401 `Token expired` |
| Rate limit | 키별 분당 호출 수 (Redis, 60초 윈도) | 429 |
| 사용량 집계 | 응답 `usage`의 prompt/completion 토큰, 요청 수를 키에 누적 (스트리밍은 마지막 청크에 usage 있을 때만) | - |
| 과부하 | DB 커넥션 풀 고갈 시 | 503 + `Retry-After: 5` |

## 6. 외부 사용자 대상이 아닌 노출 경로

인그레스로 외부에서 도달은 가능하지만, GenOS 로그인 세션(JWT) 기반의 UI 백엔드라 외부 연동용 API로 보지 않는다.

| 경로 | 서비스 | 비고 |
|---|---|---|
| `/api/admin/` | admin-api | 관리자 UI 백엔드 |
| `/api/cdn/` | cdn-api | 파일 서빙 |
| `/api/notify/` | notify-api | 알림 |
| `/api/container-status/`, `/api/monitoring/resource/` | 모니터링 | 내부 상태 조회 |
| `/flowise300/api` 등 | Flowise | 워크플로우 빌더 UI/API |
| `/grafana/`, `/minio/`, `/module/rabbitmq-stomp/` | 서드파티 | 운영용 |

## 7. 확인 필요

- 실제 운영 클러스터(dl-prod)의 VirtualService가 이 저장소 manifest와 동일한지는 클러스터에서 확인하지 않았다.
- `/v1/completions` 등 가이드 외 엔드포인트는 서빙 엔진 종류에 따라 지원 여부가 다르다.
