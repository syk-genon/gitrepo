# bok-develop 미반영 이슈 분석 (장애/보안/취약점/결함/개선)

- 대상: 한국은행(HAN) 로컬 배포 = `bok-develop` 브랜치
- 기준: bok-develop 워킹트리 실물 대조 (bok-develop은 origin/develop 대비 11,645 커밋 뒤, 고유 273 커밋)
- 작성일: 2026-08-05

## 요약

YouTrack 전체 643건 중 장애(INCIDENT)+결함(Bug)+개선+보안/취약점 합집합(중복 제거 134건)을 대상으로,
플랫폼 공통 결함/보안 후보를 bok-develop 코드와 대조한 결과 **미반영 & HAN 적용 가능 = 5건**.

| 이슈 | 대상 서비스 | 확신도 | 방치 리스크 | 파일 수 | 난이도 | HAN 우선순위 |
|---|---|---|---|---|---|---|
| KIC-20 | task-api | 확정 | 높음(브로커 장애·적재 유실, 누적성) | 3 | 낮음 | 높음 |
| KIC-29 | admin-api | 미적용(중간) | 중(관리 기능 마비·재기동 유발) | 1 | 낮음 | 높음 |
| SAMSUNGCARD-127 | admin-api | 확정 | 중(외부서빙·역할변경 간헐 500) | 2+ | 낮음 | 중~높음 |
| KIC-15 | cdn-api | 확정 | 중(다운로드 간헐 실패) | 1 | 낮음 | 중 |
| KOBCI-188 | preprocess-api/전처리기 | 확정 | 조건부(대형 PDF만) | 3+ | 낮음~중 | 조건부 |

권장 착수 순서: KIC-20 → KIC-29 → SAMSUNGCARD-127 → KIC-15 → (해당 시) KOBCI-188

---

## 1. KIC-20 — task-api Celery/RabbitMQ 좀비 큐·graceful 종료

**방치 시 문제**
- `celery_config.py:79,81` `worker_send_task_events=True`/`task_send_sent_event=True` → 소비자 없는 `celeryev.*` 큐 무한 누적 → RabbitMQ 메모리/디스크 압박 → 장기적으로 브로커 성능 저하·장애. 시간이 갈수록 악화.
- graceful 종료 미설정 → 워커 재기동/파드 종료 시 진행 중 적재 작업 강제 중단(SIGKILL) → 문서 적재 유실·정합성 훼손.

**수정 범위** (3파일, ~12줄, 난이도 낮음)
- `task-api/src/config/celery_config.py`: 2개 값 True→False, `control_queue_expires=60.0`·`control_queue_ttl=10.0` 추가
- `task-api/supervisor/supervisord.conf`: 각 program에 `stopwaitsecs=60`·`killasgroup=true`·`stopasgroup=true`
- `k8s-manifests/llmops/llmops-task-api.yaml`: `terminationGracePeriodSeconds: 90`

## 2. KIC-15 — cdn-api MinIO presigned URL 초기화 경합

**방치 시 문제**
- `minio_utility.py`가 `_client`를 먼저 노출하고 `_PRESIGNED_URL_EXPIRES`(:49)를 init 맨 끝에 세팅 → 재기동 직후 동시요청이 초기화 완료 전 `presigned_get_object()` 진입 시 `AttributeError` → 파일 다운로드/미리보기 간헐 실패. race condition이라 불규칙 재현.

**수정 범위** (1파일, ~3~8줄, 난이도 낮음)
- `cdn-api/src/utility/minio_utility.py`: `_PRESIGNED_URL_EXPIRES`를 클래스 기본값으로 선세팅하거나 `_client` 공개 전 원자적 설정(초기화 순서 재배치 또는 lock).

## 3. KOBCI-188 — 전처리기 Gunicorn timeout / 동시처리 한계

**방치 시 문제**
- gunicorn `timeout=3600`(default-preprocessor·preprocess-api), nginx `1h` → 1시간 초과 대형 PDF(수백 페이지) 적재가 worker timeout으로 중단 → 대형 문서 VDB 적재 실패.
- 복제본을 늘려도 동시 처리량 ~5개로 제한 → 대량 적재 시 적체·지연.

**수정 범위** (config 3파일 ~6줄 = 쉬움 / 동시처리 구조 = 중간)
- `container-services/preprocessors/default-preprocessor/configs/gunicorn_conf.py`, `preprocess-api/configs/gunicorn_conf.py`, `preprocess-api/configs/nginx.conf`: timeout 1일 정합화
- (추가) preprocessor Service/Endpoint·HTTP 커넥션·worker 구조 조정 → 복제본×worker 동시처리 (조사 필요)
- 주의: HAN이 1시간 초과 대형 PDF를 실제로 다루지 않으면 우선순위 낮음.

## 4. SAMSUNGCARD-127 — admin-api AsyncSession lazy loading (MissingGreenlet)

**방치 시 문제**
- 외부 서빙 배포 경로(`serving_service_async.py:2005`)와 사용자 역할 변경 경로(`user_service.py:280/336/565`)에서 eager load 없이 relationship 접근 → 조건 충족 시 `sqlalchemy.exc.MissingGreenlet` 500 에러 → 해당 기능 간헐 실패. HAN은 외부 API 서빙을 실제 사용하므로 배포 시 발생 가능.

**수정 범위** (2파일 확정 + 유사 지점, ~10~20줄, 난이도 낮음)
- `serving_service_async.py:1806` 쿼리에 `.options(selectinload(ServingRevision.external_api))` 추가
- `user_service.py`: `session.get(User, id)` 3개 지점 → `select(User).options(selectinload(User.roles))` 교체 또는 roles 명시 조회
- (이슈 언급 ResourceGroup.resources 삭제검증·FNC sync는 HAN 존재 여부 확인 후 반영 — FNC/IAM sync는 삼성카드 전용 가능성)

## 5. KIC-29 — admin-api redis 'share' 캐시 동시 커넥션 경합

**방치 시 문제**
- `aio_cache_utils.py:39-52`의 RedisCache에 커넥션 풀 사이징 없음 → 벡터DB 상세 진입 시 4개 동시요청 중 `@cached(alias='share')` 경로에서 `readexactly() … already waiting` → 관리자 '문서 목록' 조회 지속 실패, 새로고침으로 해소 안 되어 서비스 재기동 필요. 데이터 손상은 없으나 관리 기능 마비.

**수정 범위** (1파일 예상, ~수줄, 난이도 낮음·확신 중간)
- `aio_cache_utils.py get_config`에 커넥션 풀 설정(`pool_max_size` 등) 추가 → 동시 op가 커넥션 공유하지 않도록.
- 선행 권장: 원본 KIC 수정 커밋으로 정확한 fix 형태 확정(develop 도달 히스토리에서는 미발견).

---

## 해당 없음 (기능/서비스 부재 → 백포트 불필요)
- KIC-30 Temporal 워커(NAV/MPOWER/펀드/ETF) — 삼성증권 전용
- KOBCI-130 VDB 2단계 승인 트랜잭션 — `document_upsert_approval_event` 미존재
- KOBCI-185 Dots-mOCR parser — 코드 미존재
- KOBCI-187 workflow Socket.IO multi-pod — 해당 socketio 구조 미존재
- SAMSUNGCARD-188/189 genportal-api CVE — genportal-api 서비스 자체가 레포에 없음
- KOBCI-113 / KOBCI-129 — RabbitMQ/MongoDB PV 인프라 이슈(코드 아님)
- KOGAS-39 Mate citation 파서 — 가스공사 전용 커스텀 스텝
- KOBCI-65 — 원인 분석(코드 수정 아님)
