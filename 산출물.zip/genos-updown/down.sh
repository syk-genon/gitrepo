#!/usr/bin/env bash
# usage: bash ./down.sh [--all] [-y]
#   (옵션 없음) DB/인프라(weaviate, mongodb, mariadb, nfs-client-provisioner)만 내림. 앱 deploy는 그대로 유지
#   --all       앱 deploy까지 replicas 0으로 내림. 원래 replicas는 replicas_latest.txt에 저장 -> up.sh가 복원
#   -y          확인 프롬프트 생략

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPLICAS_FILE="${SCRIPT_DIR}/replicas_latest.txt"

NS=llmops
ALL=false
ASSUME_YES=false
# --all 이어도 앱 단계에서 내리지 않는 deploy (아래 인프라 단계에서 내리거나 up.sh가 먼저 올리는 것)
INFRA_DEPLOYS="nfs-client-provisioner llmops-mongodb-deployment llmops-rabbitmq-stomp-deployment maxscale"
APP_POD_TIMEOUT=300

for ARG in "$@"; do
	case "$ARG" in
		-all|--all) ALL=true ;;
		-y|--yes) ASSUME_YES=true ;;
		*) echo "unknown option: $ARG"; echo "usage: bash ./down.sh [--all] [-y]"; exit 1 ;;
	esac
done

LOG_FILE="script_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG_FILE") 2>&1

kubectl vsphere login --server=192.168.22.226 -u minds@vsphere.local --insecure-skip-tls-verify --tanzu-kubernetes-cluster-namespace=inno-dev-ns --tanzu-kubernetes-cluster-name=inno-ai-tkc

# 앱 deploy 목록: "이름 replicas" (인프라 제외)
APP_DEPLOYS=""
if $ALL; then
	if [ -f "${REPLICAS_FILE}" ]; then
		echo "[Error] ${REPLICAS_FILE} 가 이미 있습니다. 이전 --all 내림이 아직 복원되지 않았습니다."
		echo "        덮어쓰면 원래 replicas가 0으로 기록되므로 중단합니다. up.sh로 먼저 복원하거나 파일 내용을 확인하세요."
		exit 1
	fi
	while read -r NAME COUNT; do
		[ -z "$NAME" ] && continue
		[[ " ${INFRA_DEPLOYS} " == *" ${NAME} "* ]] && continue
		APP_DEPLOYS+="${NAME} ${COUNT}"$'\n'
	done < <(kubectl -n ${NS} get deploy -o go-template='{{range .items}}{{.metadata.name}} {{.spec.replicas}}{{"\n"}}{{end}}')
fi

echo "=================================================================="
echo " [WARNING] GenOS shut down - namespace: ${NS}"
if $ALL; then
	echo " mode: --all  앱 deploy $(printf '%s' "${APP_DEPLOYS}" | grep -c .)개를 0으로 내린 뒤 DB/인프라를 내립니다."
	echo "       원래 replicas는 ${REPLICAS_FILE} 에 저장되고 up.sh가 복원합니다."
else
	echo " mode: 기본  DB/인프라만 내립니다. 앱 deploy는 유지됩니다. (앱까지 내리려면 --all)"
fi
echo "=================================================================="
if ! $ASSUME_YES; then
	read -r -p "계속하려면 yes 입력: " ANSWER
	if [ "$ANSWER" != "yes" ]; then
		echo "중단"
		exit 1
	fi
fi

wait_deploy_pods_gone() {
	local DEPLOY=$1
	local SELECTOR
	local ELAPSED=0
	SELECTOR=$(kubectl -n ${NS} get deploy/${DEPLOY} -o go-template='{{range $k, $v := .spec.selector.matchLabels}}{{$k}}={{$v}},{{end}}')
	SELECTOR=${SELECTOR%,}
	while [ -n "$(kubectl -n ${NS} get pod -l "${SELECTOR}" --no-headers 2>/dev/null)" ]; do
		if [ ${ELAPSED} -ge ${APP_POD_TIMEOUT} ]; then
			return 1
		fi
		sleep 5
		ELAPSED=$((ELAPSED + 5))
	done
}

echo "Start for genos shut down"

if $ALL; then
	echo "[Processing] app deploys scaled down"
	printf '%s' "${APP_DEPLOYS}" > "${REPLICAS_FILE}"
	echo "원래 replicas 저장: ${REPLICAS_FILE}"
	while read -r NAME COUNT; do
		[ -z "$NAME" ] && continue
		kubectl -n ${NS} scale deploy/${NAME} --replicas=0
	done <<< "${APP_DEPLOYS%$'\n'}"

	STUCK=()
	while read -r NAME COUNT; do
		[ -z "$NAME" ] && continue
		wait_deploy_pods_gone "${NAME}" || STUCK+=("${NAME}")
	done <<< "${APP_DEPLOYS%$'\n'}"
	if [ ${#STUCK[@]} -gt 0 ]; then
		echo "[Warning] ${APP_POD_TIMEOUT}s 안에 파드가 정리되지 않은 deploy: ${STUCK[*]}"
		echo "          (Terminating 상태로 남은 파드는 kubectl -n ${NS} get pod 로 확인) DB/인프라 내림은 계속 진행합니다."
	fi
	echo "[Success] app deploys scaled down"
fi

echo "[Processing] sts/weaviate scaled down"
kubectl -n ${NS} scale sts/weaviate --replicas=0
kubectl -n ${NS} wait --for=delete pod -l app=weaviate --timeout=100s
echo "[Success] sts/weaviate scaled down"

echo "[Processing] deploy/llmops-mongodb-deployment scaled down"
kubectl -n ${NS} scale deploy/llmops-mongodb-deployment --replicas=0
kubectl -n ${NS} wait --for=delete pod -l app=llmops-mongodb-deployment --timeout=100s
echo "[Success] deploy/llmops-mongodb-deployment scaled down"

echo "[Processing] sts/mariadb-mariadb-galera scaled down"
kubectl -n ${NS} scale sts/mariadb-mariadb-galera --replicas=0
kubectl -n ${NS} wait --for=delete pod -l app.kubernetes.io/instance=mariadb,app.kubernetes.io/name=mariadb-galera --timeout=100s
echo "[Success] sts/mariadb-mariadb-galera scaled down"

echo "[Processing] deploy/nfs-client-provisioner scaled down"
kubectl -n ${NS} scale deploy/nfs-client-provisioner --replicas=0
kubectl -n ${NS} wait --for=delete pod -l app=nfs-client-provisioner --timeout=10s
echo "[Success] deploy/nfs-client-provisioner scaled down"

echo "Completed for genos shut down"
