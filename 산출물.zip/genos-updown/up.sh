#!/usr/bin/env bash
# usage: bash ./up.sh
#   down.sh --all 로 내렸다면 replicas_latest.txt 의 원래 replicas로 앱 deploy를 복원하고,
#   복원 후 파일은 replicas_restored_<시각>.txt 로 이름을 바꿉니다.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPLICAS_FILE="${SCRIPT_DIR}/replicas_latest.txt"

LOG_FILE="script_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG_FILE") 2>&1

NS=llmops

kubectl vsphere login --server=192.168.22.226 -u minds@vsphere.local --insecure-skip-tls-verify --tanzu-kubernetes-cluster-namespace=inno-dev-ns --tanzu-kubernetes-cluster-name=inno-ai-tkc

echo "Start for kube node setting"
echo ""

NODES=$(kubectl get nodes -o custom-columns=NAME:.metadata.name --no-headers | grep -E '^inno-ai-tkc-wl-pools')
declare -A NODE_MAP

for NODE in $NODES; do
	kubectl label nodes $NODE node-role.mnc.ai/cpu=true --overwrite
	kubectl label nodes $NODE node-role.mnc.ai/database=true --overwrite
	echo "$NODE 라벨 부여 완료 "
	KEY=$(echo $NODE | cut -d'-' -f7)
	NODE_MAP[$KEY]=$NODE
done
echo "[Success] node labeling"
echo ""

echo "Start for genos boot up"
echo ""

echo "[Processing] deploy/istio scaled up"
kubectl -n istio-system scale deploy/istiod --replicas=2
kubectl -n istio-system scale deploy/istio-ingressgateway --replicas=2
kubectl rollout restart deploy/istiod -n istio-system
kubectl rollout restart deploy/istio-ingressgateway -n istio-system
kubectl rollout status deploy/istiod -n istio-system --timeout=120s
kubectl rollout status deploy/istio-ingressgateway -n istio-system --timeout=120s
sleep 10s
echo "[Success] deploy/istio scaled up"
echo ""

echo "[Processing] deploy/nfs-client-provisioner scaled up"
kubectl -n ${NS} scale deploy/nfs-client-provisioner --replicas=2
sleep 5s
kubectl -n ${NS} wait --for=condition=Ready pod -l app=nfs-client-provisioner --timeout=10s
sleep 20s
echo "[Success] deploy/nfs-client-provisioner scaled up"
echo ""

echo "[Processing] sts/mariadb-mariadb-galera scaled up"
kubectl -n ${NS} scale sts/mariadb-mariadb-galera --replicas=1
sleep 5s
kubectl -n ${NS} wait --for=condition=Ready pod -l app.kubernetes.io/instance=mariadb,app.kubernetes.io/name=mariadb-galera --timeout=300s
kubectl -n ${NS} rollout restart deploy/maxscale
kubectl -n ${NS} rollout status deploy/maxscale --timeout=120s
echo "[Success] sts/mariadb-mariadb-galera scaled up"
echo ""

echo "[Processing] sts/weaviate scaled up"
kubectl -n ${NS} scale sts/weaviate --replicas=1
sleep 5s
kubectl -n ${NS} wait --for=condition=Ready pod -l app=weaviate --timeout=300s
echo "[Success] sts/weaviate scaled up"
echo ""

echo "[Processing] deploy rabbitmq, mongodb scaled up"
kubectl -n ${NS} rollout restart deploy/llmops-rabbitmq-stomp-deployment
sleep 5s
kubectl -n ${NS} rollout status deploy/llmops-rabbitmq-stomp-deployment --timeout=120s

kubectl -n ${NS} scale deploy/llmops-mongodb-deployment --replicas=1
kubectl -n ${NS} rollout status deploy/llmops-mongodb-deployment --timeout=300s
echo "[Success] deploy rabbitmq, mongodb scaled up"
echo ""

echo "[Processing] Node DB update"
for KEY in "${!NODE_MAP[@]}"; do
	NODE_VAL=${NODE_MAP[$KEY]}
	kubectl -n $NS exec mariadb-mariadb-galera-0 -- mariadb -uroot -pmnc1! llmops -e "UPDATE system_node_tb SET name = '$NODE_VAL' WHERE name like '%-$KEY-%';"
	echo "$NODE_VAL DB 수정 완료"
done

echo "[NODE_value_SETUP]"
TARGET_DEPLOYS=$(kubectl -n $NS get deploy -o name | grep -E 'serving-|doc-parser-|preprocessor-')
for DEPLOY in $TARGET_DEPLOYS; do
	OLD_NODE=$(kubectl -n $NS get $DEPLOY -o jsonpath='{.spec.template.spec.affinity.nodeAffinity.requiredDuringSchedulingIgnoredDuringExecution.nodeSelectorTerms[0].matchExpressions[0].values[0]}' 2>/dev/null || echo "")
	if [ -n "$OLD_NODE" ]; then
		OLD_KEY=$(echo $OLD_NODE | cut -d'-' -f7)
		NEW_VAL=${NODE_MAP[$OLD_KEY]:-}

		if [ -n "$NEW_VAL" ]; then
			echo "[PATCHING] $DEPLOY : $OLD_NODE -> $NEW_VAL"
			kubectl -n $NS patch $DEPLOY --type='json' -p="[{\"op\":\"replace\", \"path\": \"/spec/template/spec/affinity/nodeAffinity/requiredDuringSchedulingIgnoredDuringExecution/nodeSelectorTerms/0/matchExpressions/0/values/0\", \"value\": \"$NEW_VAL\"}]"
		fi
	fi
done

echo "[Processing] restart All modules"
# down.sh --all 로 내린 deploy는 저장된 replicas로 scale, 나머지는 기존처럼 rollout restart
declare -A SAVED_REPLICAS
if [ -f "${REPLICAS_FILE}" ]; then
	while read -r NAME COUNT; do
		[ -z "$NAME" ] && continue
		SAVED_REPLICAS[$NAME]=$COUNT
	done < "${REPLICAS_FILE}"
	echo "${REPLICAS_FILE} 발견: deploy ${#SAVED_REPLICAS[@]}개 원래 replicas로 복원"
fi

FAILED=()
DEPLOY_NAME=$(kubectl get deploy -n ${NS} | awk '{print $1}' | grep -v nfs | grep -v NAME)
for i in ${DEPLOY_NAME};
do
	if [ -n "${SAVED_REPLICAS[$i]:-}" ]; then
		kubectl -n ${NS} scale deploy/$i --replicas=${SAVED_REPLICAS[$i]}
	else
		kubectl -n ${NS} rollout restart deploy/$i
	fi
	# 하나가 늦어도 나머지 deploy 복원은 계속 진행
	kubectl -n ${NS} rollout status deploy/$i --timeout=120s || FAILED+=("$i")
done

if [ -f "${REPLICAS_FILE}" ]; then
	mv "${REPLICAS_FILE}" "${SCRIPT_DIR}/replicas_restored_$(date +%Y%m%d_%H%M%S).txt"
fi

if [ ${#FAILED[@]} -gt 0 ]; then
	echo "[Warning] 120s 안에 Ready 되지 않은 deploy: ${FAILED[*]}"
	echo "          kubectl -n ${NS} get pod 로 상태 확인 필요"
else
	echo "[Success] restart All modules"
fi
echo ""
echo "[Success] Completed for genos up"
