#!/usr/bin/env bash
# usage: bash ./up_recommended.sh [-n NS] [--context CTX] [--replicas-file FILE] [--exclude a,b,...] [--apply] [-y]
#   원래 replicas를 모르는 상태에서 replicas 0 인 deploy/sts를 추천값으로 올립니다.
#   (옵션 없음) 계획만 출력하고 아무것도 바꾸지 않음 (dry-run)
#   --apply              실제로 scale 실행
#   -n NS                namespace (기본 llmops)
#   --context CTX        kube context 지정 (기본: 현재 context). vsphere login은 하지 않음
#   --replicas-file FILE down.sh --all 이 남긴 replicas_latest.txt / replicas_restored_*.txt 가 있으면 그 값을 최우선 사용
#   --exclude a,b        올리지 않을 deploy/sts 이름 (원래 0이었던 것)
#   -y                   확인 프롬프트 생략
#
# 추천 replicas 규칙 (우선순위 순)
#   1. 현재 replicas > 0      -> 건드리지 않음
#   2. --replicas-file 에 있음 -> 파일 값
#   3. 그 외 replicas 0       -> 1
#      - k8s-manifests/llmops 의 앱 매니페스트가 전부 replicas 1(또는 미지정=1)
#      - serving/preprocessor 등 orchestrator 생성 deploy도 DB 기본값이 replicas 1, GPU 사용 시 1 고정
#      - mariadb-galera는 0에서 올릴 때 1개로 부트스트랩해야 하므로 1 (3노드 확장은 별도로)
#   GPU 를 요청하는 deploy는 계획표에 GPU 표시. 테스트서버 GPU가 모자라면 --exclude 로 빼세요.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

NS=llmops
CONTEXT=""
REPLICAS_FILE=""
EXCLUDE=""
APPLY=false
ASSUME_YES=false
DEFAULT_REPLICAS=1
INFRA_TIMEOUT=300s
APP_TIMEOUT=300

while [ $# -gt 0 ]; do
	case "$1" in
		-n|--namespace) NS=$2; shift ;;
		--context) CONTEXT=$2; shift ;;
		--replicas-file) REPLICAS_FILE=$2; shift ;;
		--exclude) EXCLUDE=$2; shift ;;
		--apply) APPLY=true ;;
		-y|--yes) ASSUME_YES=true ;;
		*) echo "unknown option: $1"; sed -n '2,10p' "$0"; exit 1 ;;
	esac
	shift
done

LOG_FILE="${SCRIPT_DIR}/script_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG_FILE") 2>&1

k() {
	if [ -n "${CONTEXT}" ]; then
		kubectl --context "${CONTEXT}" "$@"
	else
		kubectl "$@"
	fi
}

declare -A SAVED_REPLICAS
if [ -n "${REPLICAS_FILE}" ]; then
	[ -f "${REPLICAS_FILE}" ] || { echo "[Error] ${REPLICAS_FILE} 없음"; exit 1; }
	while read -r NAME COUNT; do
		[ -z "$NAME" ] && continue
		SAVED_REPLICAS[$NAME]=$COUNT
	done < "${REPLICAS_FILE}"
fi

declare -A EXCLUDED
IFS=',' read -r -a EXCLUDE_LIST <<< "${EXCLUDE}"
for NAME in "${EXCLUDE_LIST[@]}"; do
	[ -n "$NAME" ] && EXCLUDED[$NAME]=1
done

# "kind/name current target gpu reason"
PLAN=()
declare -A TARGET

collect() {
	local KIND=$1
	local NAME COUNT GPU
	while read -r NAME COUNT GPU; do
		[ -z "$NAME" ] && continue
		local KEY="${KIND}/${NAME}"
		local GPU_MARK="-"
		[ -n "${GPU:-}" ] && GPU_MARK="GPU"
		if [ "${COUNT}" != "0" ]; then
			continue
		elif [ -n "${EXCLUDED[$NAME]:-}" ]; then
			PLAN+=("${KEY} 0 0 ${GPU_MARK} excluded")
		elif [ -n "${SAVED_REPLICAS[$NAME]:-}" ]; then
			TARGET[$KEY]=${SAVED_REPLICAS[$NAME]}
			PLAN+=("${KEY} 0 ${SAVED_REPLICAS[$NAME]} ${GPU_MARK} replicas-file")
		else
			TARGET[$KEY]=${DEFAULT_REPLICAS}
			PLAN+=("${KEY} 0 ${DEFAULT_REPLICAS} ${GPU_MARK} recommended")
		fi
	done < <(k -n "${NS}" get "${KIND}" -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.spec.replicas}{" "}{.spec.template.spec.containers[*].resources.limits.nvidia\.com/gpu}{"\n"}{end}')
}

collect deploy
collect sts

CURRENT_CONTEXT=$(k config current-context)
echo "=================================================================="
echo " [WARNING] GenOS scale up (recommended replicas)"
echo " context  : ${CURRENT_CONTEXT}"
echo " namespace: ${NS}"
if $APPLY; then
	echo " mode     : --apply  아래 계획대로 실제 scale 합니다."
else
	echo " mode     : dry-run  계획만 출력합니다. 실행하려면 --apply"
fi
echo "=================================================================="
printf '%-60s %7s %7s %4s %s\n' "RESOURCE" "CURRENT" "TARGET" "GPU" "REASON"
for ROW in "${PLAN[@]}"; do
	# shellcheck disable=SC2086
	printf '%-60s %7s %7s %4s %s\n' ${ROW}
done
echo "replicas 0 인 대상: ${#PLAN[@]}개 (replicas > 0 인 리소스는 건드리지 않음)"

if ! $APPLY; then
	exit 0
fi
if [ ${#TARGET[@]} -eq 0 ]; then
	echo "올릴 대상이 없습니다."
	exit 0
fi
if ! $ASSUME_YES; then
	read -r -p "context ${CURRENT_CONTEXT} / ns ${NS} 에 적용하려면 yes 입력: " ANSWER
	if [ "$ANSWER" != "yes" ]; then
		echo "중단"
		exit 1
	fi
fi

# 의존 순서대로 먼저 올리는 인프라 (up.sh 순서와 동일). 대상에 없으면 건너뜀
scale_and_wait() {
	local KEY=$1
	[ -z "${TARGET[$KEY]:-}" ] && return 0
	echo "[Processing] ${KEY} -> ${TARGET[$KEY]}"
	k -n "${NS}" scale "${KEY}" --replicas="${TARGET[$KEY]}"
	k -n "${NS}" rollout status "${KEY}" --timeout=${INFRA_TIMEOUT} || echo "[Warning] ${KEY} ${INFRA_TIMEOUT} 안에 Ready 안 됨, 계속 진행"
	unset "TARGET[$KEY]"
}

scale_and_wait deploy/nfs-client-provisioner
scale_and_wait sts/mariadb-mariadb-galera
scale_and_wait deploy/maxscale
scale_and_wait sts/weaviate
scale_and_wait deploy/llmops-weaviate-deployment
scale_and_wait deploy/llmops-rabbitmq-stomp-deployment
scale_and_wait deploy/llmops-mongodb-deployment
scale_and_wait deploy/llmops-redis

echo "[Processing] 나머지 ${#TARGET[@]}개 scale up"
for KEY in "${!TARGET[@]}"; do
	k -n "${NS}" scale "${KEY}" --replicas="${TARGET[$KEY]}"
done

# 한꺼번에 올린 뒤 전체 대기 (하나씩 기다리면 너무 오래 걸림)
FAILED=()
DEADLINE=$(( $(date +%s) + APP_TIMEOUT ))
for KEY in "${!TARGET[@]}"; do
	REMAIN=$(( DEADLINE - $(date +%s) ))
	[ ${REMAIN} -lt 1 ] && REMAIN=1
	k -n "${NS}" rollout status "${KEY}" --timeout="${REMAIN}s" >/dev/null 2>&1 || FAILED+=("${KEY}")
done

if [ ${#FAILED[@]} -gt 0 ]; then
	echo "[Warning] ${APP_TIMEOUT}s 안에 Ready 되지 않은 리소스 ${#FAILED[@]}개:"
	printf '  %s\n' "${FAILED[@]}"
	echo "  Pending이면 GPU/노드 자원 부족 가능성 -> kubectl -n ${NS} describe pod 로 확인"
	echo "  원래 0이던 리소스라면: kubectl -n ${NS} scale <resource> --replicas=0"
else
	echo "[Success] all scaled up"
fi
