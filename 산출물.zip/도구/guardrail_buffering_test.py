#!/usr/bin/env python3
"""응답 가드레일의 스트리밍 버퍼링을 측정하고, 실패 지점(유휴 타임아웃)을 찾는다.

배경
  filters/genos/guardrail.py:276-281 이 응답 스트림을 통째로 받아 쌓은 뒤에야 내보낸다.
  가드레일을 켜면 생성이 끝날 때까지 클라이언트로 단 1바이트도 나가지 않는다.
  가드레일을 끄면 guardrail.py:115 에서 바로 통과하므로 스트리밍이 유지된다.

  전체 소요 시간은 양쪽이 같다. 차이는 첫 바이트까지 걸리는 시간(TTFB)에만 나타난다.
  그래서 p95 같은 지표로는 보이지 않는다.

측정 방법
  max_tokens 를 단계적으로 올려 생성 시간을 늘리면서 OFF/ON 을 번갈아 호출한다.
  ON 의 TTFB 가 전체 시간에 근접하면 버퍼링이다.
  생성이 충분히 길어지면 무응답 구간이 유휴 타임아웃을 넘겨 요청이 깨진다.
  깨지기 시작하는 지점이 그 타임아웃 값이다.

  비200 응답은 상태코드, Location, 본문 앞부분까지 그대로 보여준다.

표준 라이브러리만 쓴다. 폐쇄망에서 pip 설치 없이 실행 가능하다.

사용법
  export TOKEN='<서빙 인증키>'
  python3 guardrail_buffering_test.py \
      --gw http://llmops-gateway-api-service.llmops.svc.cluster.local:8080 \
      --serving-id 109 --revision 460 --model gemma-4-31b --guardrail 10
"""
import argparse
import json
import ssl
import sys
import time
import urllib.error
import urllib.request

DEFAULT_STEPS = [64, 512, 2048, 4000]
DEFAULT_PROMPT = (
    '조선시대의 주요 왕들을 순서대로 들고, 각 왕의 치세에 있었던 일을 '
    '가능한 한 자세히 서술해줘. 분량 제한 없이 길게 써도 된다.'
)
BODY_HEAD_CHARS = 300
# TTFB 가 전체의 이 비율을 넘으면 버퍼링으로 본다.
BUFFER_RATIO = 0.8
# TTFB 가 이 비율 아래면 스트리밍으로 본다.
STREAM_RATIO = 0.3


class NoRedirect(urllib.request.HTTPRedirectHandler):
    """리다이렉트를 따라가지 않는다.

    urllib 은 기본적으로 302 를 따라가고 POST 를 GET 으로 바꾼다.
    그러면 정작 누가 어디로 보냈는지가 사라지므로, 3xx 를 그대로 받아 진단한다.
    """

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_opener = urllib.request.build_opener(NoRedirect)


def build_headers(args, guardrail_on):
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'text/event-stream',
        'Authorization': f'Bearer {args.token}',
        'x-genos-is-external': 'true',
        'x-genos-serving-revision-id': str(args.revision),
    }
    if guardrail_on:
        headers['x-genos-guardrail'] = 'true'
        headers['x-genos-request-guardrail'] = args.guardrail
        headers['x-genos-response-guardrail'] = args.guardrail
    return headers


def call_once(url, headers, payload, timeout, insecure):  # noqa: ARG001
    """요청 1건. 첫 바이트 시각과 전체 시각, 실패 시 진단 정보를 돌려준다."""
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(url, data=body, method='POST', headers=headers)
    start = time.perf_counter()
    try:
        with _opener.open(req, timeout=timeout) as resp:
            first = resp.read(1)
            ttfb = time.perf_counter() - start
            rest = resp.read()
            total = time.perf_counter() - start
            raw = (first + rest).decode('utf-8', 'ignore')
            frames = [ln for ln in raw.split('\n\n') if ln.strip()]
            return {'status': resp.status, 'ttfb': ttfb, 'total': total,
                    'frames': len(frames), 'bytes': len(first) + len(rest)}
    except urllib.error.HTTPError as e:
        total = time.perf_counter() - start
        detail = ''
        try:
            detail = e.read().decode('utf-8', 'ignore')[:BODY_HEAD_CHARS]
        except OSError:
            pass
        return {'status': e.code, 'ttfb': None, 'total': total, 'kind': 'http',
                'headers': dict(e.headers), 'body_head': detail}
    except Exception as exc:                     # noqa: BLE001
        return {'status': 'ERR', 'ttfb': None, 'total': time.perf_counter() - start,
                'kind': 'disconnect', 'error': f'{type(exc).__name__}: {exc}'}


def verdict(row):
    if row['status'] != 200 or row['ttfb'] is None:
        return '실패'
    if row['total'] <= 0:
        return '-'
    ratio = row['ttfb'] / row['total']
    if ratio >= BUFFER_RATIO:
        return '버퍼링'
    if ratio <= STREAM_RATIO:
        return '스트리밍'
    return '판단보류'


def show_failure(label, row):
    print(f'      [{label} 실패 상세]')
    if 'error' in row:
        print(f'        {row["error"]}')
        if 'timed out' in row['error'].lower():
            print('        무응답이 클라이언트 타임아웃을 넘겼다. --timeout 을 늘려 다시 볼 것.')
        return
    print(f'        상태코드 {row["status"]}')
    for key in ('Location', 'Content-Type', 'Retry-After', 'Server'):
        value = row.get('headers', {}).get(key)
        if value:
            print(f'        {key}: {value}')
    if row.get('body_head'):
        print(f'        본문: {row["body_head"]}')
    if row['status'] in (301, 302, 307, 308):
        print('        리다이렉트다. Location 이 외부 도메인이면 상대측,')
        print('        내부 경로면 서빙 파드의 프록시 설정을 볼 것.')


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--gw', required=True, help='게이트웨이 base URL')
    ap.add_argument('--serving-id', required=True)
    ap.add_argument('--revision', required=True)
    ap.add_argument('--model', required=True)
    ap.add_argument('--token', default='', help='미지정 시 환경변수 TOKEN')
    ap.add_argument('--guardrail', required=True,
                    help='가드레일 ID. 활성 규칙이 있는 것이어야 한다. '
                         '규칙이 없으면 필터가 아무 일도 하지 않아 OFF 와 같아진다')
    ap.add_argument('--path-prefix', default='')
    ap.add_argument('--steps', default=','.join(map(str, DEFAULT_STEPS)),
                    help='max_tokens 단계. 쉼표 구분')
    ap.add_argument('--prompt', default=DEFAULT_PROMPT)
    ap.add_argument('--timeout', type=int, default=900, help='클라이언트 타임아웃(초)')
    ap.add_argument('--insecure', action='store_true')
    ap.add_argument('--yes', action='store_true', help='확인 프롬프트 생략')
    args = ap.parse_args()

    import os
    args.token = args.token or os.environ.get('TOKEN', '')
    if not args.token:
        print('TOKEN 이 비어 있다. --token 또는 환경변수 TOKEN 을 줄 것.')
        return 2

    steps = [int(s) for s in args.steps.split(',') if s.strip()]
    url = (f"{args.gw.rstrip('/')}{args.path_prefix}"
           f"/rep/serving/{args.serving_id}/v1/chat/completions")

    print(f'대상      : {url}')
    print(f'모델      : {args.model}   가드레일 {args.guardrail}')
    print(f'단계      : max_tokens {steps}')
    print(f'호출 수   : {len(steps) * 2}건 (단계마다 OFF/ON)')
    print()
    print('  외부 API 서빙이면 호출이 과금된다. max_tokens 가 큰 단계는 그만큼 비싸다.')
    if not args.yes:
        if input('  계속하려면 GO 를 입력: ').strip() != 'GO':
            print('취소했다.')
            return 1
    print()

    print(f"{'max_tokens':>10} {'조건':>4} {'코드':>5} {'첫바이트':>9} {'전체':>8} "
          f"{'비율':>6} {'프레임':>6}  판정")
    print('-' * 72)

    results = []
    first_failure = None
    http_failure = None
    for max_tokens in steps:
        payload = {'model': args.model, 'stream': True, 'max_tokens': max_tokens,
                   'messages': [{'role': 'user', 'content': args.prompt}]}
        for on in (False, True):
            label = 'ON' if on else 'OFF'
            row = call_once(url, build_headers(args, on), payload, args.timeout, args.insecure)
            row['max_tokens'], row['on'] = max_tokens, on
            results.append(row)

            ttfb_txt = f'{row["ttfb"]:8.2f}s' if row['ttfb'] is not None else '       -'
            ratio_txt = (f'{row["ttfb"] / row["total"] * 100:5.0f}%'
                         if row['ttfb'] is not None and row['total'] > 0 else '     -')
            frames_txt = f'{row.get("frames", "-"):>6}'
            print(f'{max_tokens:>10} {label:>4} {str(row["status"]):>5} {ttfb_txt} '
                  f'{row["total"]:7.2f}s {ratio_txt} {frames_txt}  {verdict(row)}')
            sys.stdout.flush()

            if row['status'] != 200:
                show_failure(label, row)
                # 끊김만 유휴 타임아웃 후보다. HTTP 상태코드는 별개 문제다.
                if on and first_failure is None and row.get('kind') == 'disconnect':
                    first_failure = row
                if row.get('kind') == 'http' and http_failure is None:
                    http_failure = row

    print()
    print('=' * 72)
    print('요약')
    print('=' * 72)

    off_ok = [r for r in results if not r['on'] and r['status'] == 200 and r['ttfb'] is not None]
    on_ok = [r for r in results if r['on'] and r['status'] == 200 and r['ttfb'] is not None]

    def mean_ratio(rows):
        vals = [r['ttfb'] / r['total'] for r in rows if r['total'] > 0]
        return sum(vals) / len(vals) if vals else None

    off_ratio, on_ratio = mean_ratio(off_ok), mean_ratio(on_ok)
    if off_ratio is not None and on_ratio is not None:
        print(f'  첫 바이트 비율   OFF {off_ratio * 100:.0f}%   ON {on_ratio * 100:.0f}%')
        if on_ratio >= BUFFER_RATIO and off_ratio <= STREAM_RATIO:
            print('  판정: 응답 가드레일이 스트리밍을 버퍼링한다. 확정.')
            print('        생성이 끝날 때까지 클라이언트로 0바이트가 나간다.')
            print('        전체 시간은 양쪽이 같으므로 지연 지표로는 보이지 않는다.')
        elif on_ratio <= STREAM_RATIO:
            print('  판정: 버퍼링 없음. ON 도 스트리밍된다.')
            print('        가드레일에 활성 규칙이 없어 필터가 건너뛰었을 수 있다.')
            print('        게이트웨이 로그에서 RESPONSE GUARDRAILS 줄을 확인할 것.')
        else:
            print('  판정: 애매하다. 단계를 늘려 다시 볼 것.')
    else:
        print('  성공한 측정이 부족해 비교할 수 없다.')

    if http_failure:
        print()
        print(f'  HTTP {http_failure["status"]} 가 나왔다. 부하나 타임아웃 문제가 아니라')
        print('  요청 자체가 거절된 것이다. 위의 실패 상세를 먼저 볼 것.')

    if first_failure:
        mt = first_failure['max_tokens']
        print()
        print(f'  ON 이 처음 깨진 지점: max_tokens={mt}, 경과 {first_failure["total"]:.0f}초')
        print('  이 시간이 유휴 타임아웃 값에 가깝다. Istio/Envoy 와 인그레스 설정을 대조할 것.')
    elif on_ok:
        longest = max(on_ok, key=lambda r: r['total'])
        print()
        print(f'  ON 이 깨진 단계는 없다. 가장 긴 무응답 구간 {longest["total"]:.0f}초까지 견뎠다.')
        print('  --steps 로 더 큰 max_tokens 를 주면 한계를 찾을 수 있다.')

    print()
    print('  주의: 이 측정은 스크립트가 도는 파드에서 게이트웨이까지의 경로만 본다.')
    print('        실제 사용자는 인그레스를 한 번 더 거치므로 타임아웃이 더 짧을 수 있다.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
