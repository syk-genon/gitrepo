#!/usr/bin/env bash
#
#  외부 API 서빙 경로 측정
#
#  측정으로 확정된 것 (2026-09-21 스테이징 5회 실행)
#    - 요청 경로에 커넥션 누수는 없다. 순증은 풀 워밍업이며 포화하면 멈춘다.
#      실측: 순증 +11(200건) -> +6(600건) -> +0(600건). 요청을 3배로 늘려도 0 이었다.
#    - 부하 1~8 rps 에서 에러 0, p95 1.0~1.4초. 게이트웨이는 병목이 아니다.
#
#  확정된 장애 메커니즘 (로컬 재현)
#    DB 경로가 응답을 멈추면 - 연결은 살아 있고 응답만 없는 상태 - 진행 중이던
#    쿼리가 무한 대기하고 점유한 커넥션이 반납되지 않는다. 풀이 영구 고갈되며
#    부하가 빠져도 회복되지 않아 프로세스 재시작이 유일한 해결책이 된다.
#    read_timeout 10초로 수정했다. 이 시험은 그 조건을 만들지 않으므로
#    여기서 정상이라고 해서 장애가 재현되지 않는 것이 문제는 아니다.
#
#  아직 시험하지 않은 유일한 조건: 가드레일 ON
#    최초 제보가 "가드레일 켜면 실패, 끄면 빠르게 성공" 이었다.
#    응답 가드레일은 스트리밍을 통째로 버퍼링한 뒤에야 내보내므로(guardrail.py:276-281)
#    생성이 끝날 때까지 클라이언트로 단 1바이트도 가지 않는다.
#    그래서 이 시험의 핵심 지표는 커넥션이 아니라 첫 바이트까지 걸리는 시간(TTFB) 이다.
#
#  ####################################################################
#  #  주의: 외부 API 는 과금되고 상대측 rate limit 이 있다.           #
#  #        기본값은 운영 부하(약 2 rps) 수준으로 제한해 두었다.      #
#  #        RAMP_MAX 를 함부로 올리지 말 것.                          #
#  #        누수 측정을 2회 반복하므로 호출량이 종전의 2배다.         #
#  ####################################################################
#
#  사용법:
#     export DBPW='<mariadb root password>'
#     export TOKEN='<외부 서빙 인증키>'
#     export SERVING=<외부 API 서빙 ID>
#     export REVISION=<리비전 ID>
#     export MODEL='<모델명>'
#     export GUARDRAIL=<가드레일 ID>        # 선택. 지정하면 가드레일 A/B 를 추가 실행
#     bash run_external.sh
#
set -u

GW=${GW:-http://llmops-gateway-api-service.llmops.svc.cluster.local:8080}
SERVING=${SERVING:-}
REVISION=${REVISION:-}
MODEL=${MODEL:-}
COUNT=${COUNT:-600}
RPS=${RPS:-2}
SETTLE=${SETTLE:-180}
RAMP_MAX=${RAMP_MAX:-8}
OUTDIR=${OUTDIR:-./exttest_$(date +%y%m%d_%H%M%S)}

# 가드레일. GUARDRAIL 하나만 주면 요청/응답 양쪽에 같은 값을 쓴다.
GUARDRAIL=${GUARDRAIL:-}
GUARDRAIL_REQ=${GUARDRAIL_REQ:-$GUARDRAIL}
GUARDRAIL_RES=${GUARDRAIL_RES:-$GUARDRAIL}

# 2회 반복 중 2회차 순증이 1회차의 이 비율 이하로 줄면 워밍업으로 본다.
WARMUP_RATIO=${WARMUP_RATIO:-50}
# 순증이 이 값 이하면 애초에 유의하지 않은 것으로 본다.
NOISE_FLOOR=${NOISE_FLOOR:-3}
# TTFB 표본 수
TTFB_SAMPLES=${TTFB_SAMPLES:-3}

HERE=$(cd "$(dirname "$0")" && pwd)
LOAD="$HERE/loadtest.py"
CONNCMD=${CONNCMD:-"python3 $HERE/conncount.py"}

die() { echo; echo "[중단] $*" >&2; exit 1; }

[ -f "$LOAD" ] || die "$LOAD 이 없다."
[ -n "${TOKEN:-}" ] || die "TOKEN 이 비어 있다."
[ -n "$SERVING" ]   || die "SERVING 이 비어 있다. 외부 API 서빙 ID 를 지정할 것."
[ -n "$REVISION" ]  || die "REVISION 이 비어 있다."
[ -n "$MODEL" ]     || die "MODEL 이 비어 있다."
[ -n "${DBPW:-}" ]  || die "DBPW 가 비어 있다."

COMMON=(
  --base-url "$GW" --path-prefix '' --serving-id "$SERVING" --token "$TOKEN"
  --model "$MODEL"
  --header "x-genos-is-external: true"
  --header "x-genos-serving-revision-id: $REVISION"
)

GUARDRAIL_ARGS=()
if [ -n "$GUARDRAIL_REQ$GUARDRAIL_RES" ]; then
  GUARDRAIL_ARGS=(
    --header "x-genos-guardrail: true"
    --header "x-genos-request-guardrail: $GUARDRAIL_REQ"
    --header "x-genos-response-guardrail: $GUARDRAIL_RES"
  )
fi

mkdir -p "$OUTDIR"
echo "결과 저장: $OUTDIR"
echo "대상 서빙: $SERVING / 리비전 $REVISION / $MODEL"
if [ ${#GUARDRAIL_ARGS[@]} -gt 0 ]; then
  echo "가드레일  : 요청 $GUARDRAIL_REQ / 응답 $GUARDRAIL_RES  (A/B 시험 포함)"
else
  echo "가드레일  : 미지정. GUARDRAIL 을 주면 A/B 시험이 추가된다"
fi
echo
cat <<'WARN'
  ┌──────────────────────────────────────────────────────────┐
  │  외부 API 서빙 대상 시험이다. 호출이 과금될 수 있고       │
  │  상대측 rate limit 에 걸릴 수 있다.                       │
  │  기본 부하는 운영 수준(2 rps)으로 제한돼 있다.            │
  │  누수 측정을 2회 반복하므로 호출량이 종전의 2배다.        │
  └──────────────────────────────────────────────────────────┘
WARN
printf '계속하려면 GO 를 입력: '
read -r ANS
[ "$ANS" = "GO" ] || die "취소했다."
echo

# ---------------------------------------------------------------- 사전 점검
echo "[사전 1/5] DB 커넥션 조회"
BASE=$($CONNCMD 2>&1) || die "conncount 실패: $BASE"
echo "           현재 $BASE"
echo "           주의: 클러스터 전체 커넥션이다. 게이트웨이 것만 세는 값이 아니다."

echo "[사전 2/5] DNS 조회 시간 (이 파드 기준. 게이트웨이 파드와 다를 수 있다)"
python3 - "$GW" > "$OUTDIR/dns.txt" 2>&1 <<'PY'
import socket, sys, time, urllib.parse
hosts = ['llmops-mariadb-service']
h = urllib.parse.urlparse(sys.argv[1]).hostname
if h: hosts.append(h)
for host in hosts:
    best = None
    for _ in range(3):
        t = time.perf_counter()
        try:
            socket.getaddrinfo(host, 443)
        except Exception as e:
            print(f'{host:<58} 실패 {e.__class__.__name__}')
            best = None
            break
        d = (time.perf_counter() - t) * 1000
        best = d if best is None else min(best, d)
    if best is not None:
        flag = '   <== 느림. executor 경합 위험' if best > 50 else ''
        print(f'{host:<58} {best:7.1f} ms{flag}')
PY
cat "$OUTDIR/dns.txt"

echo "[사전 3/5] 비스트리밍 probe"
python3 "$LOAD" "${COMMON[@]}" --no-pii --probe --timeout 180 \
  > "$OUTDIR/probe_nostream.txt" 2>&1
grep -q "^HTTP 200" "$OUTDIR/probe_nostream.txt" \
  || die "probe 실패. $OUTDIR/probe_nostream.txt 확인"
echo "           OK"

echo "[사전 4/5] 스트리밍 probe"
python3 "$LOAD" "${COMMON[@]}" --no-pii --stream --probe --timeout 180 \
  > "$OUTDIR/probe_stream.txt" 2>&1
grep -q "^HTTP 200" "$OUTDIR/probe_stream.txt" \
  || die "스트리밍 probe 실패. $OUTDIR/probe_stream.txt 확인"
echo "           OK  $(grep -o 'SSE 프레임 [0-9]*개' "$OUTDIR/probe_stream.txt" | head -1)"

# ------------------------------------------------------------------- TTFB
#  첫 바이트까지 걸리는 시간. 응답 가드레일이 스트리밍을 버퍼링하면
#  전체 생성 시간이 끝나야 첫 바이트가 나오므로 여기서 드러난다.
ttfb_probe() {
  local label="$1"; shift
  local out="$OUTDIR/ttfb_${label}.txt"
  : > "$out"
  local i
  for i in $(seq 1 "$TTFB_SAMPLES"); do
    curl -sS -N -o /dev/null \
      -w '%{time_starttransfer} %{time_total} %{http_code}\n' \
      --max-time 300 \
      -H "Authorization: Bearer $TOKEN" \
      -H 'Content-Type: application/json' \
      -H 'x-genos-is-external: true' \
      -H "x-genos-serving-revision-id: $REVISION" \
      "$@" \
      -d "{\"model\":\"$MODEL\",\"stream\":true,\"messages\":[{\"role\":\"user\",\"content\":\"한국의 수도와 그 도시의 역사를 세 문단으로 설명해줘.\"}]}" \
      "$GW/rep/serving/$SERVING/v1/chat/completions" >> "$out" 2>&1
  done
  awk '{ttfb+=$1; tot+=$2; if($3!="200") bad++} END {
         if (NR==0) {print "측정 실패"; exit}
         printf "첫 바이트 %.2fs   전체 %.2fs   비200 %d건 / %d회\n",
                ttfb/NR, tot/NR, bad+0, NR }' "$out"
}

echo "[사전 5/5] 첫 바이트까지 걸리는 시간 (TTFB)"
printf '           가드레일 OFF  '
ttfb_probe off
if [ ${#GUARDRAIL_ARGS[@]} -gt 0 ]; then
  printf '           가드레일 ON   '
  ttfb_probe on \
    -H 'x-genos-guardrail: true' \
    -H "x-genos-request-guardrail: $GUARDRAIL_REQ" \
    -H "x-genos-response-guardrail: $GUARDRAIL_RES"
  echo "           ON 의 첫 바이트가 전체 시간에 가깝다면 응답 버퍼링이다."
  # OFF 와 ON 이 구별되지 않으면 필터가 아무 일도 하지 않은 것이다.
  # 가드레일에 활성 규칙이 없으면 _load_guardrail 이 빈 목록을 돌려주고
  # 요청/응답 분기가 모두 건너뛰어져 OFF 와 같은 경로가 된다.
  python3 - "$OUTDIR/ttfb_off.txt" "$OUTDIR/ttfb_on.txt" <<'PY'
import sys
def avg(path):
    rows = [l.split() for l in open(path) if l.split()]
    if not rows: return None, None
    return (sum(float(r[0]) for r in rows) / len(rows),
            sum(float(r[1]) for r in rows) / len(rows))
o_ttfb, o_tot = avg(sys.argv[1])
n_ttfb, n_tot = avg(sys.argv[2])
if None in (o_ttfb, n_ttfb):
    sys.exit()
if abs(n_ttfb - o_ttfb) < 0.5 and n_ttfb < n_tot * 0.5:
    print('           [경고] OFF 와 ON 의 첫 바이트가 거의 같다.')
    print('                  가드레일 필터가 실제로 동작하지 않았을 수 있다.')
    print('                  게이트웨이 로그에서 다음을 확인할 것:')
    print('                    IS GUARDRAIL APPLIED :: true')
    print('                    RESPONSE GUARDRAILS: <ID>')
    print('                  RESPONSE GUARDRAILS 줄이 없으면 그 가드레일에 활성 규칙이 없다.')
PY
fi
echo

# -------------------------------------------------------------------- 시험
#  누수 판정은 2회 반복해서 순증이 줄어드는지로 본다.
#  1회만 보고 '순증 / 요청 수' 로 판정하면 풀 워밍업을 누수로 오판한다.
run_leak() {
  local tag="$1"; shift
  python3 "$LOAD" "${COMMON[@]}" "$@" --no-pii --history 1 --stream \
    --leak --leak-count "$COUNT" --leak-rps "$RPS" --leak-settle "$SETTLE" \
    --conn-cmd "$CONNCMD" 2>&1 | tee "$OUTDIR/leak_${tag}.txt"
}

net_growth() {
  # '순증 +13   요청 600건 ...' 에서 13 을 꺼낸다. 없으면 빈 문자열.
  grep -E '^순증' "$1" 2>/dev/null | head -1 \
    | sed -E 's/^순증[[:space:]]*\+?(-?[0-9]+).*/\1/'
}

echo "[1/3] 누수 측정 1회차 - 스트리밍, 운영과 동일 조건 ($RPS rps)"
run_leak run1
echo
echo "[2/3] 누수 측정 2회차 - 동일 조건 반복"
echo "      풀이 이미 더워졌으므로, 워밍업이라면 순증이 크게 줄어든다."
run_leak run2
echo

G1=$(net_growth "$OUTDIR/leak_run1.txt")
G2=$(net_growth "$OUTDIR/leak_run2.txt")

VERDICT="판정 불가 (순증 값을 읽지 못했다)"
if [ -n "$G1" ] && [ -n "$G2" ]; then
  if [ "$G2" -le "$NOISE_FLOOR" ]; then
    VERDICT="누수 없음. 2회차 순증 ${G2} 는 잡음 수준이다."
  elif [ $((G2 * 100)) -le $((G1 * WARMUP_RATIO)) ]; then
    VERDICT="워밍업. 순증이 ${G1} -> ${G2} 로 줄었다. 한 번 더 돌리면 0 에 수렴한다."
  else
    VERDICT="누수 의심. 순증이 ${G1} -> ${G2} 로 줄지 않았다. 요청 수에 비례하는지 --leak-count 를 3배로 늘려 확인할 것."
  fi
fi

echo "=========================================================="
echo "누수 판정 (2회 비교)"
echo "=========================================================="
echo "  1회차 순증 ${G1:-?}   2회차 순증 ${G2:-?}"
echo "  $VERDICT"
echo
echo "  참고: 도구가 각 회차 끝에 출력하는 '판정:' 줄은 1회분만 보고 내리므로"
echo "        워밍업을 누수로 오판한다. 위의 2회 비교 결과를 따를 것."
echo

echo "[3/3] 소폭 램프 - 1 rps 부터 $RAMP_MAX rps 까지"
echo "      (외부 API 과금/rate limit 때문에 상한을 낮게 둔다)"
python3 "$LOAD" "${COMMON[@]}" --no-pii --history 1 --stream \
  --ramp --ramp-start 1 --ramp-factor 2 --ramp-max "$RAMP_MAX" --ramp-step 60 \
  --concurrency 256 --conn-cmd "$CONNCMD" 2>&1 | tee "$OUTDIR/ramp_stream.txt"
echo

# ------------------------------------------------------------- 가드레일 A/B
if [ ${#GUARDRAIL_ARGS[@]} -gt 0 ]; then
  echo "=========================================================="
  echo "가드레일 A/B - 같은 부하를 OFF/ON 으로 각각"
  echo "=========================================================="
  echo "  관심사는 커넥션이 아니라 에러율과 첫 바이트 시간이다."
  echo
  echo "[A] 가드레일 OFF"
  python3 "$LOAD" "${COMMON[@]}" --no-pii --history 1 --stream \
    --rps "$RPS" --duration 120 --concurrency 256 \
    --conn-cmd "$CONNCMD" 2>&1 | tee "$OUTDIR/ab_off.txt"
  echo
  echo "[B] 가드레일 ON"
  python3 "$LOAD" "${COMMON[@]}" "${GUARDRAIL_ARGS[@]}" --no-pii --history 1 --stream \
    --rps "$RPS" --duration 120 --concurrency 256 \
    --conn-cmd "$CONNCMD" 2>&1 | tee "$OUTDIR/ab_on.txt"
  echo
fi

# -------------------------------------------------------------------- 요약
echo "=========================================================="
echo "요약"
echo "=========================================================="
echo "  [DNS 조회 시간]"
sed 's/^/      /' "$OUTDIR/dns.txt"
echo
echo "  [첫 바이트 시간]"
printf '      가드레일 OFF  '
awk '{ttfb+=$1; tot+=$2} END {if(NR)printf "첫 바이트 %.2fs   전체 %.2fs\n", ttfb/NR, tot/NR}' "$OUTDIR/ttfb_off.txt"
if [ -f "$OUTDIR/ttfb_on.txt" ]; then
  printf '      가드레일 ON   '
  awk '{ttfb+=$1; tot+=$2} END {if(NR)printf "첫 바이트 %.2fs   전체 %.2fs\n", ttfb/NR, tot/NR}' "$OUTDIR/ttfb_on.txt"
fi
echo
echo "  [누수]"
echo "      1회차 순증 ${G1:-?}   2회차 순증 ${G2:-?}"
echo "      $VERDICT"
echo
echo "  [램프]"
grep -E '^\s+[0-9]+\.[0-9]' "$OUTDIR/ramp_stream.txt" 2>/dev/null | sed 's/^/      /'
grep -E '^종료 사유' "$OUTDIR/ramp_stream.txt" 2>/dev/null | sed 's/^/      /'
if [ -f "$OUTDIR/ab_on.txt" ]; then
  echo
  echo "  [가드레일 A/B]"
  # 고정 rps 모드는 '응답 200=' 줄이 아니라 표를 출력한다. 데이터 행을 꺼낸다.
  printf '      OFF  '; grep -E '^[[:space:]]+[0-9]+\.[0-9]' "$OUTDIR/ab_off.txt" 2>/dev/null | head -1 | sed 's/^ *//'
  printf '      ON   '; grep -E '^[[:space:]]+[0-9]+\.[0-9]' "$OUTDIR/ab_on.txt" 2>/dev/null | head -1 | sed 's/^ *//'
  echo '           (열: rps 전송 200 503 500 기타 p50 p95 첫바이트 inflight 커넥션)'
fi
echo
cat <<'GUIDE'
해석
  [첫 바이트 시간]
    가드레일 ON 의 첫 바이트가 전체 시간에 가깝다  -> 응답 버퍼링 확정.
        생성이 끝날 때까지 한 바이트도 안 나간다. 유휴 타임아웃에 걸려 실패한다.
        리즈닝처럼 생성이 길수록 잘 터진다. 커넥션 풀과는 무관한 별개 결함이다.
    OFF 와 ON 이 비슷하다                          -> 버퍼링은 원인이 아니다.

  [가드레일 A/B]
    ON 만 에러가 난다                              -> 최초 제보 재현. 에러 종류를 볼 것.
        QueuePool/503  -> 풀 경로
        타임아웃/연결 끊김 -> 버퍼링 경로
    둘 다 정상                                     -> 이 부하와 이 서빙에서는 재현 안 됨.

  [누수]
    2회 비교 결과만 신뢰할 것. 1회분 '순증' 은 풀 워밍업과 구분되지 않는다.
    워밍업 상한은 워커 10개 x pool_size 20 = 200 이다. 그 아래에서 멈추면 정상이다.

  [500 / 503]
    503 이면 수정 후 이미지에서 풀 고갈이 실제로 일어난 것이다. 500 이면 수정 전 이미지다.
    둘 다 없으면 이 시험 조건에서는 풀 고갈이 발생하지 않은 것이다.
    이 시험은 DB 무응답 조건을 만들지 않으므로, 정상이라고 해서 장애가 없다는 뜻은 아니다.

  [DNS]
    수십 ms 이상이면 executor 경합 가설이 강해진다.
    단 이 측정은 스크립트가 도는 파드 기준이라 게이트웨이 파드와 다를 수 있다.
GUIDE
echo
echo "원본 로그: $OUTDIR/"
