#!/usr/bin/env python3
"""loadtest.py 를 고친다. 같은 디렉토리에서 한 번만 실행한다.

  1. 누수 판정을 전반/후반 증가분 비교로 바꾼다.
     기존은 순증 절대값만 봐서 풀 워밍업을 누수로 오판했다.
     워밍업은 풀이 차면 멈추므로 후반 증가분이 작아지고,
     누수는 요청 수에 비례하므로 전반과 후반이 비슷하다.
  2. 첫 바이트까지 걸리는 시간(TTFB)을 측정해 출력한다.
     응답 가드레일이 스트리밍을 통째로 버퍼링하면 TTFB 로만 드러난다.
     전체 시간은 버퍼링 여부와 무관하게 같다.

원본은 loadtest.py.bak 으로 남긴다.
"""
import pathlib
import shutil
import sys

MARKER = '# [patched] ttfb + leak-verdict'

SRC = pathlib.Path('loadtest.py')
if not SRC.exists():
    sys.exit('loadtest.py 가 이 디렉토리에 없다.')

text = SRC.read_text(encoding='utf-8')

# 대상이 진짜 부하 도구인지 확인한다.
# 이 스크립트를 loadtest.py 로 잘못 복사하면 자기 자신을 고치려 들기 때문이다.
if 'def sub(old, new' in text and 'loadtest.py.bak' in text:
    sys.exit('loadtest.py 가 이 패치 스크립트로 덮여 있다.\n'
             '  loadtest.py.bak 이 원본이면: cp loadtest.py.bak loadtest.py\n'
             '  없으면 원본 loadtest.py 를 다시 받아야 한다.')
for need in ('def send_once(', 'def leak_test(', '--leak-count'):
    if need not in text:
        sys.exit(f'loadtest.py 가 예상한 부하 도구가 아니다. {need} 를 찾지 못했다.')

if MARKER in text:
    sys.exit('이미 적용돼 있다.')

done = []


def sub(old, new, count=1):
    global text
    n = text.count(old)
    if n < count:
        sys.exit(f'[실패] 다음 부분을 찾지 못했다 (발견 {n}회):\n{old[:120]}')
    text = text.replace(old, new, count)
    done.append(old.strip().splitlines()[0][:60])


# -- 1. Stats 가 TTFB 를 모으게 한다 -----------------------------------------
sub("""        self.codes = Counter()
        self.latencies = []
        self.errors = Counter()""",
    """        self.codes = Counter()
        self.latencies = []
        self.ttfbs = []
        self.errors = Counter()""")

sub("""    def record(self, code, elapsed, err=None):
        with self.lock:
            self.inflight -= 1
            self.sent += 1
            self.codes[code] += 1
            self.latencies.append(elapsed)
            if err:""",
    """    def record(self, code, elapsed, err=None, ttfb=None):
        with self.lock:
            self.inflight -= 1
            self.sent += 1
            self.codes[code] += 1
            self.latencies.append(elapsed)
            if ttfb is not None:
                self.ttfbs.append(ttfb)
            if err:""")

sub("""            codes, lat, errs = self.codes, self.latencies, self.errors
            mx = self.max_inflight
            self.codes, self.latencies, self.errors = Counter(), [], Counter()
            self.max_inflight = self.inflight
            return codes, lat, errs, mx""",
    """            codes, lat, errs = self.codes, self.latencies, self.errors
            ttfbs, mx = self.ttfbs, self.max_inflight
            self.codes, self.latencies, self.errors = Counter(), [], Counter()
            self.ttfbs = []
            self.max_inflight = self.inflight
            return codes, lat, errs, mx, ttfbs""")

# -- 2. send_once 가 첫 바이트 시간을 잰다 -----------------------------------
sub("def send_once(url, token, payload, timeout, stats, insecure, extra_headers=None):",
    "def send_once(url, token, payload, timeout, stats, insecure, extra_headers=None,\n"
    "              measure_ttfb=False):")

sub("""        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            resp.read()
            stats.record(resp.status, time.perf_counter() - start)""",
    """        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            ttfb = None
            if measure_ttfb:
                # 첫 바이트가 도착할 때까지의 시간.
                # 응답 가드레일이 스트리밍을 통째로 버퍼링하면 이 값이 전체 시간에 근접한다.
                resp.read(1)
                ttfb = time.perf_counter() - start
            resp.read()
            stats.record(resp.status, time.perf_counter() - start, ttfb=ttfb)""")

# 두 군데의 submit 모두 스트리밍일 때 TTFB 를 재게 한다
sub("""            pool.submit(send_once, url, args.token, payload,
                        args.timeout, stats, args.insecure, extra_headers)""",
    """            pool.submit(send_once, url, args.token, payload,
                        args.timeout, stats, args.insecure, extra_headers,
                        bool(args.stream))""")
sub("""        pool.submit(send_once, url, args.token, payload,
                    args.timeout, stats, args.insecure, extra_headers)""",
    """        pool.submit(send_once, url, args.token, payload,
                    args.timeout, stats, args.insecure, extra_headers,
                    bool(args.stream))""")

# -- 3. 누수 측정: 전송 중 표본을 남긴다 -------------------------------------
sub("""    interval = 1.0 / args.leak_rps if args.leak_rps > 0 else 0
    peak = base""",
    """    interval = 1.0 / args.leak_rps if args.leak_rps > 0 else 0
    peak = base
    samples = []          # (보낸 건수, 커넥션 수). 전반/후반 비교에 쓴다""")

sub("""                c = conn()
                peak = max(peak, c)
                print(f'      {i + 1:4d}/{args.leak_count}  커넥션 {c}')""",
    """                c = conn()
                peak = max(peak, c)
                samples.append((i + 1, c))
                print(f'      {i + 1:4d}/{args.leak_count}  커넥션 {c}')""")

sub("""    codes, lat, errs, mx = stats.drain()
    total, ok, c503, c500, other, p50, p95, _ = summarize(codes, lat, mx)
    print(f'      응답  200={ok} 503={c503} 500={c500} 기타={other}  p95={p95:.2f}s')""",
    """    codes, lat, errs, mx, ttfbs = stats.drain()
    total, ok, c503, c500, other, p50, p95, _ = summarize(codes, lat, mx)
    ttfb_txt = f'  첫바이트={percentile(ttfbs, 50):.2f}s' if ttfbs else ''
    print(f'      응답  200={ok} 503={c503} 500={c500} 기타={other}  p95={p95:.2f}s{ttfb_txt}')""")

# -- 4. 누수 판정을 전반/후반 비교로 바꾼다 ----------------------------------
sub("""    if delta <= 2:
        print('판정: 누수 없음. 커넥션이 정상 반납된다.')
    elif delta < 10:
        print('판정: 경미한 증가. 풀 워밍업일 수 있다. --leak-count 를 3배로 늘려 재측정할 것.')
        print('      요청 수에 비례해 순증이 커지면 누수다.')
    else:
        print('판정: 누수 확인. 요청 수에 비례해 커넥션이 반납되지 않는다.')
        print(f'      이 비율이면 5분에 1건 기준 하루 {288 * delta / max(total, 1):.0f}개가 쌓인다.')""",
    """    # 풀 워밍업과 누수는 순증 절대값으로 구분되지 않는다.
    # 워밍업은 풀이 다 차면 증가가 멎으므로 후반 증가분이 전반보다 작다.
    # 누수는 요청 수에 비례하므로 전반과 후반의 증가분이 비슷하다.
    first_half = second_half = None
    if len(samples) >= 4:
        mid = len(samples) // 2
        first_half = samples[mid][1] - base
        second_half = samples[-1][1] - samples[mid][1]
        print(f'전송 전반 {first_half:+d}   후반 {second_half:+d}'
              f'   (전반은 baseline 대비, 후반은 중간지점 대비)')
        print()

    if delta <= 2:
        print('판정: 누수 없음. 커넥션이 정상 반납된다.')
    elif second_half is not None and second_half <= max(1, first_half * 0.4):
        print(f'판정: 풀 워밍업. 증가가 전반 {first_half:+d} 에서 후반 {second_half:+d} 로 멎었다.')
        print('      누수라면 요청 수에 비례해 후반에도 같은 폭으로 늘어야 한다.')
        print('      확인하려면 같은 조건으로 한 번 더 돌린다. 순증이 0 에 수렴하면 워밍업이다.')
        print('      워밍업 상한은 워커 수 x pool_size 다 (운영은 10 x 20 = 200).')
    elif second_half is None:
        print('판정: 표본이 부족해 워밍업과 구분할 수 없다. --leak-count 를 늘릴 것.')
    else:
        print('판정: 누수 의심. 후반에도 증가가 멎지 않았다.')
        print(f'      이 비율이면 5분에 1건 기준 하루 {288 * delta / max(total, 1):.0f}개가 쌓인다.')
        print('      --leak-count 를 3배로 늘려 순증이 비례해 커지는지 확인할 것.')

    print()
    print('주의: --conn-cmd 가 세는 값은 클러스터 전체 DB 커넥션이다.')
    print('      게이트웨이 것만 세는 값이 아니므로 다른 서비스의 증감이 섞인다.')""")

# -- 5. 표에 첫 바이트 열을 넣는다 -------------------------------------------
sub("""        print(f"{'rps':>7} {'전송':>6} {'200':>5} {'503':>5} {'500':>5} {'기타':>5} "
              f"{'p50':>7} {'p95':>7} {'inflight':>9} {'커넥션':>8}")
        print('-' * 78)""",
    """        print(f"{'rps':>7} {'전송':>6} {'200':>5} {'503':>5} {'500':>5} {'기타':>5} "
              f"{'p50':>7} {'p95':>7} {'첫바이트':>9} {'inflight':>9} {'커넥션':>8}")
        print('-' * 88)""")

sub("""            codes, lat, errs, mx = stats.drain()
            total, ok, c503, c500, other, p50, p95, _ = summarize(codes, lat, mx)
            conn_after = read_connections(args.conn_cmd)""",
    """            codes, lat, errs, mx, ttfbs = stats.drain()
            total, ok, c503, c500, other, p50, p95, _ = summarize(codes, lat, mx)
            ttfb50 = percentile(ttfbs, 50) if ttfbs else 0.0
            conn_after = read_connections(args.conn_cmd)""")

sub("""            print(f"{rps:7.1f} {total:6d} {ok:5d} {c503:5d} {c500:5d} {other:5d} "
                  f"{p50:7.2f} {p95:7.2f} {mx:9d} {conn_txt:>8}")""",
    """            print(f"{rps:7.1f} {total:6d} {ok:5d} {c503:5d} {c500:5d} {other:5d} "
                  f"{p50:7.2f} {p95:7.2f} {ttfb50:9.2f} {mx:9d} {conn_txt:>8}")""")

sub("""            rows.append({'rps': rps, 'total': total, 'ok': ok, '503': c503, '500': c500,
                         'other': other, 'p95': p95, 'max_inflight': mx,""",
    """            rows.append({'rps': rps, 'total': total, 'ok': ok, '503': c503, '500': c500,
                         'other': other, 'p95': p95, 'ttfb50': ttfb50, 'max_inflight': mx,""")

# -- 6. 램프 요약에 첫 바이트 해석을 덧붙인다 --------------------------------
sub("""            print('  증감이 0 근처로 유지되면 커넥션이 쌓이지 않는 것이고,')
            print('  단계마다 증가분이 누적되면 반납되지 않는 것이다.')""",
    """            print('  증감이 0 근처로 유지되면 커넥션이 쌓이지 않는 것이고,')
            print('  단계마다 증가분이 누적되면 반납되지 않는 것이다.')
            print('  다만 한 번의 실행만으로는 풀 워밍업과 구분되지 않는다.')
            print('  같은 조건을 두 번 돌려 두 번째 증가분이 줄면 워밍업이다.')
    if rows and any(r.get('ttfb50') for r in rows):
        print()
        print('첫 바이트 시간이 전체 지연(p50)에 근접하면 응답이 스트리밍되지 않고')
        print('버퍼링된 것이다. 응답 가드레일을 켰을 때 이 값이 뛰는지 비교할 것.')""")

shutil.copy(SRC, 'loadtest.py.bak')
# 적용 표시. 다음 실행에서 이 줄로 중복 적용을 막는다.
lines = text.splitlines(keepends=True)
insert_at = 1 if lines and lines[0].startswith('#!') else 0
lines.insert(insert_at, MARKER + '\n')
SRC.write_text(''.join(lines), encoding='utf-8')
print(f'{len(done)}곳 수정. 원본은 loadtest.py.bak')
for d in done:
    print(f'  - {d}')
