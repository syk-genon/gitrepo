#!/usr/bin/env bash
#
#  긴 생성으로 응답 가드레일 버퍼링의 실제 한계를 잰다.
#
#  확인된 사실: 응답 가드레일을 켜면 생성이 끝날 때까지 클라이언트로 0바이트가 나간다.
#              (guardrail.py:276-281 이 스트림을 통째로 소진한 뒤에야 내보낸다)
#  이 스크립트의 목적: 그 무응답 구간이 얼마나 길어지면 끊기는지 찾는 것.
#              끊긴 시각이 곧 경로상의 유휴 타임아웃 값이다.
#
#  사용법:
#     export TOKEN='<외부 서빙 인증키>'
#     export SERVING=109
#     export REVISION=460
#     export MODEL='gemma-4-31b'
#     export GUARDRAIL=10
#     bash ttfb_long.sh
#
#     MAXTOK=8000 bash ttfb_long.sh     # 생성을 더 길게
set -u

GW=${GW:-http://llmops-gateway-api-service.llmops.svc.cluster.local:8080}
SERVING=${SERVING:-}
REVISION=${REVISION:-}
MODEL=${MODEL:-}
GUARDRAIL=${GUARDRAIL:-}
MAXTOK=${MAXTOK:-4000}
MAXTIME=${MAXTIME:-900}
PROMPT=${PROMPT:-'조선시대를 태조부터 순종까지 왕별로 아주 자세히 서술해줘. 각 왕마다 재위 기간, 주요 정책, 사건을 빠짐없이 적어줘.'}

die() { echo "[중단] $*" >&2; exit 1; }
[ -n "${TOKEN:-}" ] || die "TOKEN 이 비어 있다."
[ -n "$SERVING" ]   || die "SERVING 이 비어 있다."
[ -n "$REVISION" ]  || die "REVISION 이 비어 있다."
[ -n "$MODEL" ]     || die "MODEL 이 비어 있다."

URL="$GW/rep/serving/$SERVING/v1/chat/completions"
BODY=$(printf '{"model":"%s","stream":true,"max_tokens":%s,"messages":[{"role":"user","content":"%s"}]}' \
       "$MODEL" "$MAXTOK" "$PROMPT")

echo "URL       : $URL"
echo "모델      : $MODEL   max_tokens=$MAXTOK   상한 ${MAXTIME}초"
echo "가드레일  : ${GUARDRAIL:-미지정}"
echo "TOKEN     : ${#TOKEN}자"
echo

run() {
    local label="$1"; shift
    local out code rc bytes frames
    out=$(mktemp)
    echo "[$label]"
    # -sS: 진행표시는 끄고 에러는 보여준다. -N: 버퍼링 없이 즉시 받는다.
    # Accept 를 명시한다. */* 로 보내면 인증 프록시가 브라우저 요청으로 보고 302 로 돌린다.
    local wout ttfb total
    wout=$(curl -sS -N -o "$out" \
        -w '%{time_starttransfer} %{time_total} %{http_code}' \
        --max-time "$MAXTIME" \
        -H "Authorization: Bearer $TOKEN" \
        -H 'Content-Type: application/json' \
        -H 'Accept: application/json' \
        -H 'x-genos-is-external: true' \
        -H "x-genos-serving-revision-id: $REVISION" \
        "$@" \
        -d "$BODY" \
        "$URL")
    rc=$?
    read -r ttfb total code <<< "$wout"
    printf '  첫 바이트 %ss   전체 %ss   코드 %s\n' "${ttfb:-?}" "${total:-?}" "${code:-?}"

    bytes=$(wc -c < "$out")
    frames=$(grep -c '^data:' "$out" 2>/dev/null) || true
    echo "  받은 바이트 $bytes   SSE 프레임 ${frames:-0}"

    if [ "$rc" -ne 0 ]; then
        echo "  curl 종료코드 $rc"
        case "$rc" in
            6)  echo "  -> 호스트를 찾지 못했다. GW 값을 확인할 것." ;;
            7)  echo "  -> 연결 실패. 게이트웨이 서비스가 떠 있는지 확인할 것." ;;
            28) echo "  -> ${MAXTIME}초 상한에 걸렸다. MAXTIME 을 늘려 다시 잴 것." ;;
            52) echo "  -> 서버가 아무것도 보내지 않고 끊었다. 유휴 타임아웃이 걸린 것이다." ;;
            56) echo "  -> 수신 중 연결이 끊겼다. 유휴 타임아웃이 걸린 것이다." ;;
            *)  echo "  -> 위 에러 메시지를 확인할 것." ;;
        esac
    fi

    case "$code" in
        200) : ;;
        30*) echo "  -> 리다이렉트다. 인증 프록시나 Istio 가 가로챘을 수 있다."
             echo "     -D 로 헤더를 받아 Location 과 server 를 확인할 것." ;;
        401) echo "  -> 인증 실패. TOKEN, 허용 IP, 만료일을 확인할 것." ;;
        404) echo "  -> 경로가 틀렸다. URL 을 run_external.sh 가 쓰는 것과 비교할 것." ;;
        503) echo "  -> 커넥션 풀 고갈 응답이다(수정본). 예상 밖이면 기록할 것." ;;
    esac

    if [ "$bytes" -gt 0 ]; then
        echo "  --- 응답 앞부분 ---"
        head -c 300 "$out" | tr -d '\0'
        echo
    fi
    rm -f "$out"
    echo
}

run "가드레일 OFF"

if [ -n "$GUARDRAIL" ]; then
    run "가드레일 ON" \
        -H 'x-genos-guardrail: true' \
        -H "x-genos-request-guardrail: $GUARDRAIL" \
        -H "x-genos-response-guardrail: $GUARDRAIL"

    cat <<'GUIDE'
해석
  ON 의 첫 바이트가 전체와 거의 같다        -> 버퍼링. 이미 확인된 사실이다.
  ON 만 코드 000 / 52 / 56 으로 끊긴다      -> 그 시각이 경로상의 유휴 타임아웃이다.
                                              Istio/Envoy, ingress, 클라이언트 순으로 찾을 것.
  ON 도 끝까지 성공한다                     -> 이 생성 길이로는 아직 한계에 못 미쳤다.
                                              MAXTOK 을 2배로 올려 다시 잴 것.
  OFF 는 되는데 ON 만 안 된다               -> 최초 제보 재현 완료.
GUIDE
fi
