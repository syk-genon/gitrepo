#!/usr/bin/env python3
# [patched] ttfb + leak-verdict
"""
gateway-api 커넥션 풀 고갈 재현 / 한계 측정 스크립트.

표준 라이브러리만 사용한다. 폐쇄망 장비에서 pip 설치 없이 실행 가능하다.

두 가지 모드가 있다.

[fixed]  고정 rps 로 일정 시간 부하를 건다.
[ramp]   부하를 단계적으로 올리면서 커넥션이 쌓이는지 확인하고,
         안 쌓이면 더 올려서 언제 터지는지 찾는다.  --ramp

가드레일 탐지가 다발하면 요청 1건이 커넥션을 동시에 여러 개 점유한다.
  _apply_guardrail 이 messages.[].content 필드마다 asyncio.gather 로 병렬 실행
    -> 규칙에 걸릴 때마다 탐지 로그 INSERT (@transactional) -> 커넥션 1개씩
--history 로 메시지 수를 늘리면 그만큼 동시 점유가 커진다.
--no-pii 를 주면 탐지가 발생하지 않는 순수 부하가 된다.

본문의 개인정보 형태 값은 전부 합성 더미다(카드번호는 공개 테스트 번호).
"""
import argparse
import json
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

DUMMY_EMAIL = "test.user@example.com"
DUMMY_PHONE = "010-0000-0000"
DUMMY_CARD = "4111111111111111"
DUMMY_RRN = "900101-1234567"

PII_SENTENCE = (
    "다음 문의 내용을 요약해 주세요. "
    f"연락처는 {DUMMY_PHONE} 이고 메일은 {DUMMY_EMAIL} 입니다. "
    f"결제 카드는 {DUMMY_CARD} 이며 등록번호는 {DUMMY_RRN} 입니다."
)
PLAIN_SENTENCE = "다음 문의 내용을 한 문단으로 요약해 주세요. 특별한 요청 사항은 없습니다."


class Stats:
    def __init__(self):
        self.lock = threading.Lock()
        self.codes = Counter()
        self.latencies = []
        self.ttfbs = []
        self.errors = Counter()
        self.sent = 0
        self.inflight = 0
        self.max_inflight = 0

    def start_req(self):
        with self.lock:
            self.inflight += 1
            self.max_inflight = max(self.max_inflight, self.inflight)

    def record(self, code, elapsed, err=None, ttfb=None):
        with self.lock:
            self.inflight -= 1
            self.sent += 1
            self.codes[code] += 1
            self.latencies.append(elapsed)
            if ttfb is not None:
                self.ttfbs.append(ttfb)
            if err:
                self.errors[err] += 1

    def drain(self):
        with self.lock:
            codes, lat, errs = self.codes, self.latencies, self.errors
            ttfbs, mx = self.ttfbs, self.max_inflight
            self.codes, self.latencies, self.errors = Counter(), [], Counter()
            self.ttfbs = []
            self.max_inflight = self.inflight
            return codes, lat, errs, mx, ttfbs


def percentile(values, p):
    if not values:
        return 0.0
    s = sorted(values)
    return s[min(int(len(s) * p / 100), len(s) - 1)]


def build_messages(history, with_pii):
    sentence = PII_SENTENCE if with_pii else PLAIN_SENTENCE
    messages = []
    for i in range(history):
        messages.append({"role": "user", "content": f"[{i + 1}] {sentence}"})
        if i < history - 1:
            messages.append({"role": "assistant", "content": f"[{i + 1}] 확인했습니다."})
    return messages


def send_once(url, token, payload, timeout, stats, insecure, extra_headers=None,
              measure_ttfb=False):
    stats.start_req()
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": f"Bearer {token}",
    }
    headers.update(extra_headers or {})
    req = urllib.request.Request(url, data=body, method="POST", headers=headers)
    ctx = ssl._create_unverified_context() if insecure else None
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            ttfb = None
            if measure_ttfb:
                # 첫 바이트가 도착할 때까지의 시간.
                # 응답 가드레일이 스트리밍을 통째로 버퍼링하면 이 값이 전체 시간에 근접한다.
                resp.read(1)
                ttfb = time.perf_counter() - start
            resp.read()
            stats.record(resp.status, time.perf_counter() - start, ttfb=ttfb)
    except urllib.error.HTTPError as e:
        detail = ''
        try:
            detail = e.read().decode('utf-8', 'ignore')[:100]
        except Exception:
            pass
        stats.record(e.code, time.perf_counter() - start, err=f"HTTP {e.code} {detail}")
    except Exception as e:                       # noqa: BLE001
        stats.record('err', time.perf_counter() - start, err=repr(e)[:100])


def read_connections(conn_cmd):
    """커넥션 수를 출력하는 셸 명령을 실행해 마지막 정수를 돌려준다."""
    if not conn_cmd:
        return None
    try:
        out = subprocess.run(conn_cmd, shell=True, capture_output=True,
                             text=True, timeout=30).stdout
        nums = [int(t) for t in out.replace('\n', ' ').split() if t.isdigit()]
        return nums[-1] if nums else None
    except Exception:                            # noqa: BLE001
        return None


def run_step(pool, url, args, payload, rps, duration, stats, extra_headers=None):
    """한 단계 부하를 건다. 제출한 요청이 모두 끝날 때까지 기다리지는 않는다."""
    interval = 1.0 / rps if rps > 0 else 0
    deadline = time.time() + duration
    next_at = time.time()
    while time.time() < deadline:
        pool.submit(send_once, url, args.token, payload,
                    args.timeout, stats, args.insecure, extra_headers,
                    bool(args.stream))
        next_at += interval
        sleep_for = next_at - time.time()
        if sleep_for > 0:
            time.sleep(sleep_for)
        else:
            next_at = time.time()


def summarize(codes, lat, mx):
    total = sum(codes.values())
    ok = codes.get(200, 0)
    c503 = codes.get(503, 0)
    c500 = codes.get(500, 0)
    other = total - ok - c503 - c500
    return total, ok, c503, c500, other, percentile(lat, 50), percentile(lat, 95), mx


def probe(url, args, payload, extra_headers=None):
    """요청 1건을 보내고 무엇이 돌아오는지 그대로 보여준다."""
    body = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': f'Bearer {args.token}',
    }
    headers.update(extra_headers or {})
    req = urllib.request.Request(url, data=body, method='POST', headers=headers)
    ctx = ssl._create_unverified_context() if args.insecure else None
    if extra_headers:
        for k, v in extra_headers.items():
            print(f'추가 헤더  {k}: {v}')
    print(f'요청 본문 {len(body)} bytes, 타임아웃 {args.timeout}초')
    start = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=args.timeout, context=ctx) as resp:
            raw = resp.read().decode('utf-8', 'ignore')
            print(f'HTTP {resp.status}   {time.perf_counter() - start:.2f}초')
            for k in ('content-type', 'retry-after', 'x-genos-trace-id'):
                if resp.headers.get(k):
                    print(f'  {k}: {resp.headers.get(k)}')
            print('--- 응답 ---')
            if args.stream:
                frames = [ln for ln in raw.split('\n\n') if ln.strip()]
                print(f'SSE 프레임 {len(frames)}개')
                for ln in frames[:2] + (['...'] if len(frames) > 3 else []) + frames[-2:]:
                    print(f'  {ln[:200]}')
            else:
                print(raw[:1500])
            return 0
    except urllib.error.HTTPError as e:
        raw = ''
        try:
            raw = e.read().decode('utf-8', 'ignore')
        except Exception:
            pass
        print(f'HTTP {e.code}   {time.perf_counter() - start:.2f}초')
        print('--- 응답 ---')
        print(raw[:1500])
        print()
        if e.code == 401:
            print('401: 인증키가 틀렸거나, 허용 IP / 만료일 조건에 걸렸다.')
        elif e.code == 404:
            print('404: 경로가 틀렸다. --path-prefix 와 --serving-id 를 확인한다.')
        elif e.code == 503:
            print('503: 수정본의 과부하 응답이다. 커넥션 풀 고갈일 수 있다.')
        return 1
    except Exception as e:                       # noqa: BLE001
        print(f'실패   {time.perf_counter() - start:.2f}초   {e!r}')
        print()
        print('타임아웃이면 게이트웨이가 상위 서빙의 응답을 기다리는 중일 가능성이 높다.')
        print('게이트웨이의 업스트림 호출에는 타임아웃이 없어(ClientTimeout(total=None)),')
        print('서빙이 응답하지 않으면 요청이 무한정 대기한다. 아래를 확인한다.')
        print('  1) 서빙 12 에 대표 리비전이 지정돼 있는가')
        print('     (미지정이면 게이트웨이가 serving-12-None 으로 보내 응답이 오지 않는다)')
        print('  2) 해당 서빙 파드가 Running / Ready 인가')
        print('  3) 게이트웨이 경유 헬스체크:')
        print(f'     curl -m 30 -H "Authorization: Bearer <키>" \\')
        print(f'       {url.rsplit("/v1/", 1)[0]}/healthcheck')
        return 1


def leak_test(url, args, payload, extra_headers):
    """
    소량을 천천히 보낸 뒤 커넥션이 baseline 으로 되돌아오는지 본다.

    운영에서 가드레일 트래픽은 5분에 1건 수준이다. 그 정도 빈도로도 장애가 난다면
    원인은 동시 점유가 아니라 누수다. 이 모드는 그것을 직접 측정한다.
    """
    if not args.conn_cmd:
        print('--leak 에는 --conn-cmd 가 필요하다.')
        return 2

    def conn():
        v = read_connections(args.conn_cmd)
        return -1 if v is None else v

    print('[1/3] baseline 측정 (30초 안정화)')
    time.sleep(30)
    base = conn()
    print(f'      baseline = {base}')

    stats = Stats()
    print(f'[2/3] 전송 {args.leak_count}건 @ {args.leak_rps} rps')
    interval = 1.0 / args.leak_rps if args.leak_rps > 0 else 0
    peak = base
    samples = []          # (보낸 건수, 커넥션 수). 전반/후반 비교에 쓴다
    with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        next_at = time.time()
        for i in range(args.leak_count):
            pool.submit(send_once, url, args.token, payload,
                        args.timeout, stats, args.insecure, extra_headers,
                        bool(args.stream))
            if (i + 1) % max(1, args.leak_count // 10) == 0:
                c = conn()
                peak = max(peak, c)
                samples.append((i + 1, c))
                print(f'      {i + 1:4d}/{args.leak_count}  커넥션 {c}')
            next_at += interval
            sleep_for = next_at - time.time()
            if sleep_for > 0:
                time.sleep(sleep_for)
            else:
                next_at = time.time()

    codes, lat, errs, mx, ttfbs = stats.drain()
    total, ok, c503, c500, other, p50, p95, _ = summarize(codes, lat, mx)
    ttfb_txt = f'  첫바이트={percentile(ttfbs, 50):.2f}s' if ttfbs else ''
    print(f'      응답  200={ok} 503={c503} 500={c500} 기타={other}  p95={p95:.2f}s{ttfb_txt}')
    for msg, n in errs.most_common(2):
        print(f'      └ {n}회  {msg}')

    print(f'[3/3] 전송 종료. {args.leak_settle}초 관찰 (반납 시간을 충분히 준다)')
    marks = []
    step = max(10, args.leak_settle // 6)
    waited = 0
    while waited < args.leak_settle:
        time.sleep(step)
        waited += step
        c = conn()
        marks.append((waited, c))
        print(f'      +{waited:4d}초  커넥션 {c}')

    final = marks[-1][1] if marks else conn()
    delta = final - base

    print()
    print('=' * 60)
    print(f'baseline {base}  →  전송중 최대 {peak}  →  {args.leak_settle}초 후 {final}')
    print(f'순증 {delta:+d}   요청 {total}건   요청당 {delta / max(total, 1):+.2f}개')
    print()
    # 풀 워밍업과 누수는 순증 절대값으로 구분되지 않는다.
    # 워밍업은 풀이 다 차면 증가가 멎으므로 후반 증가분이 전반보다 작다.
    # 누수는 요청 수에 비례하므로 전반과 후반의 증가분이 비슷하다.
    first_half = second_half = None
    if len(samples) >= 4:
        mid = len(samples) // 2
        first_half = samples[mid][1] - base
        second_half = samples[-1][1] - samples[mid][1]
        print(f'전송 전반 {first_half:+d}   후반 {second_half:+d}'
              f'   (전반은 baseline 대비, 후반은 중간지점 대비)')
        print()

    # 순증 한 자릿수는 클러스터 전체 커넥션의 잡음과 구분되지 않는다.
    # 다른 서비스의 증감이 그대로 섞여 들어오기 때문이다.
    if delta <= 5:
        print(f'판정: 누수 없음. 순증 {delta:+d} 는 잡음 수준이다.')
    elif second_half is not None and second_half <= max(1, first_half * 0.4):
        print(f'판정: 풀 워밍업. 증가가 전반 {first_half:+d} 에서 후반 {second_half:+d} 로 멎었다.')
        print('      누수라면 요청 수에 비례해 후반에도 같은 폭으로 늘어야 한다.')
        print('      확인하려면 같은 조건으로 한 번 더 돌린다. 순증이 0 에 수렴하면 워밍업이다.')
        print('      워밍업 상한은 워커 수 x pool_size 다 (운영은 10 x 20 = 200).')
    elif second_half is None:
        print('판정: 표본이 부족해 워밍업과 구분할 수 없다. --leak-count 를 늘릴 것.')
    else:
        print('판정: 누수 의심. 후반에도 증가가 멎지 않았다.')
        print(f'      이 비율이면 5분에 1건 기준 하루 {288 * delta / max(total, 1):.0f}개가 쌓인다.')
        print('      --leak-count 를 3배로 늘려 순증이 비례해 커지는지 확인할 것.')

    print()
    print('주의: --conn-cmd 가 세는 값은 클러스터 전체 DB 커넥션이다.')
    print('      게이트웨이 것만 세는 값이 아니므로 다른 서비스의 증감이 섞인다.')
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--base-url', required=True, help='예: https://<테스트호스트>')
    ap.add_argument('--serving-id', required=True, help='대표 리비전 기준 서빙 ID')
    ap.add_argument('--token', required=True, help='서빙 인증키(Bearer)')
    ap.add_argument('--model', default='Qwen3-8B-AWQ')
    ap.add_argument('--path-prefix', default='/api/gateway')
    ap.add_argument('--history', type=int, default=1,
                    help='대화 턴 수. 가드레일 병렬 태스크 수를 좌우한다 (기본 1)')
    ap.add_argument('--no-pii', action='store_true',
                    help='탐지에 걸리지 않는 본문 사용 (순수 부하)')
    ap.add_argument('--max-tokens', type=int, default=64)
    ap.add_argument('--stream', action='store_true',
                    help='스트리밍 요청(stream=true). 게이트웨이의 코드 경로가 달라진다. '
                         'AuthKeyBearer.streaming_wrapper 안에서 사용량 갱신이 일어나므로 '
                         '운영의 LLM 트래픽과 같은 경로를 타려면 반드시 켤 것')
    ap.add_argument('--timeout', type=int, default=120)
    ap.add_argument('--insecure', action='store_true', help='TLS 검증 생략')
    ap.add_argument('--concurrency', type=int, default=256, help='클라이언트 동시 요청 상한')

    ap.add_argument('--rps', type=float, default=2.0, help='[fixed] 요청률')
    ap.add_argument('--duration', type=int, default=300, help='[fixed] 초')

    ap.add_argument('--ramp', action='store_true', help='단계적 상승 모드')
    ap.add_argument('--ramp-start', type=float, default=1.0)
    ap.add_argument('--ramp-factor', type=float, default=2.0, help='단계별 배수')
    ap.add_argument('--ramp-max', type=float, default=64.0)
    ap.add_argument('--ramp-step', type=int, default=60, help='단계 유지 시간(초)')
    ap.add_argument('--ramp-settle', type=int, default=20,
                    help='단계 종료 후 잔여 요청 정리 대기(초)')

    ap.add_argument('--conn-cmd', default='',
                    help='커넥션 수를 출력하는 셸 명령. 마지막 정수를 사용한다')
    ap.add_argument('--conn-threshold', type=int, default=150,
                    help='이 값을 넘으면 중단 (기본 150)')
    ap.add_argument('--no-break', action='store_true', help='5xx 가 나와도 계속 진행')
    ap.add_argument('--header', action='append', default=[], metavar='KEY:VALUE',
                    help='추가 요청 헤더. 여러 번 지정 가능. '
                         '게이트웨이 서비스를 직접 호출할 때 Istio 가 넣어주는 헤더를 '
                         '직접 넣기 위해 쓴다')
    ap.add_argument('--leak', action='store_true',
                    help='누수 측정 모드. 소량을 천천히 보낸 뒤 커넥션이 baseline 으로 '
                         '되돌아오는지 본다. --conn-cmd 필수')
    ap.add_argument('--leak-count', type=int, default=60, help='[leak] 총 요청 수')
    ap.add_argument('--leak-rps', type=float, default=0.5, help='[leak] 요청률')
    ap.add_argument('--leak-settle', type=int, default=120,
                    help='[leak] 전송 종료 후 관찰 시간(초). 반납될 시간을 충분히 준다')
    ap.add_argument('--probe', action='store_true',
                    help='요청 1건만 보내고 응답 전문을 그대로 출력한다. 부하 전 연결 확인용')
    args = ap.parse_args()

    url = (f"{args.base_url.rstrip('/')}{args.path_prefix}"
           f"/rep/serving/{args.serving_id}/v1/chat/completions")

    extra_headers = {}
    for h in args.header:
        if ':' not in h:
            print(f'헤더 형식이 잘못됐다: {h}  (KEY:VALUE 형태여야 한다)')
            return 2
        k, v = h.split(':', 1)
        extra_headers[k.strip()] = v.strip()
    messages = build_messages(args.history, with_pii=not args.no_pii)
    payload = {"model": args.model, "messages": messages,
               "max_tokens": args.max_tokens, "stream": bool(args.stream)}

    print(f"대상        : {url}")
    print(f"모델        : {args.model}")
    print(f"대화 메시지 : {len(messages)}개   탐지 유발: {'없음' if args.no_pii else '있음'}")
    print(f"응답 방식   : {'스트리밍 (streaming_wrapper 경로)' if args.stream else '일반 (비스트리밍 경로)'}")
    if args.conn_cmd:
        base = read_connections(args.conn_cmd)
        print(f"커넥션 관측 : 사용   시작값 {base}   중단 임계 {args.conn_threshold}")
    else:
        print("커넥션 관측 : 없음 (--conn-cmd 미지정, 응답 코드만으로 판정)")
    print()

    if args.probe:
        return probe(url, args, payload, extra_headers)

    if args.leak:
        return leak_test(url, args, payload, extra_headers)

    stats = Stats()
    rows = []
    stop_reason = '정상 종료'

    with ThreadPoolExecutor(max_workers=args.concurrency) as pool:
        if not args.ramp:
            steps = [args.rps]
            step_dur = args.duration
        else:
            steps, r = [], args.ramp_start
            while r <= args.ramp_max:
                steps.append(r)
                r *= args.ramp_factor
            step_dur = args.ramp_step

        print(f"{'rps':>7} {'전송':>6} {'200':>5} {'503':>5} {'500':>5} {'기타':>5} "
              f"{'p50':>7} {'p95':>7} {'첫바이트':>9} {'inflight':>9} {'커넥션':>8}")
        print('-' * 88)

        for rps in steps:
            stats.drain()
            conn_before = read_connections(args.conn_cmd)
            try:
                run_step(pool, url, args, payload, rps, step_dur, stats, extra_headers)
            except KeyboardInterrupt:
                stop_reason = '사용자 중단'
                break

            if args.ramp and args.ramp_settle:
                time.sleep(args.ramp_settle)

            codes, lat, errs, mx, ttfbs = stats.drain()
            total, ok, c503, c500, other, p50, p95, _ = summarize(codes, lat, mx)
            ttfb50 = percentile(ttfbs, 50) if ttfbs else 0.0
            conn_after = read_connections(args.conn_cmd)
            conn_txt = '-' if conn_after is None else str(conn_after)

            print(f"{rps:7.1f} {total:6d} {ok:5d} {c503:5d} {c500:5d} {other:5d} "
                  f"{p50:7.2f} {p95:7.2f} {ttfb50:9.2f} {mx:9d} {conn_txt:>8}")
            for msg, n in errs.most_common(2):
                print(f"          └ {n}회  {msg}")
            sys.stdout.flush()

            rows.append({'rps': rps, 'total': total, 'ok': ok, '503': c503, '500': c500,
                         'other': other, 'p95': p95, 'ttfb50': ttfb50, 'max_inflight': mx,
                         'conn_before': conn_before, 'conn_after': conn_after})

            if total == 0:
                stop_reason = ('이 단계에서 완료된 응답이 0건이다. 대상이 응답하지 않는다. '
                               '--probe 로 단건 확인이 먼저다')
                break
            if ok == 0 and total > 0:
                stop_reason = (f'rps={rps:.1f} 에서 성공 응답이 0건이다. '
                               f'부하 한계가 아니라 대상이 정상 응답하지 않는 상태다. '
                               f'--probe 로 확인할 것')
                break
            if mx >= args.concurrency:
                stop_reason = (f'클라이언트 포화 (in-flight {mx} = 상한 {args.concurrency}). '
                               f'서버 한계가 아니라 부하도구 한계다. --concurrency 를 올릴 것')
                break
            if not args.no_break and (c500 or other):
                stop_reason = f'rps={rps:.1f} 에서 500/기타 발생 → 여기서 무너진다'
                break
            if not args.no_break and c503:
                stop_reason = f'rps={rps:.1f} 에서 503 발생 → 풀 한계 도달 (의도된 빠른 실패)'
                break
            if (conn_after is not None and conn_after >= args.conn_threshold):
                stop_reason = f'rps={rps:.1f} 에서 커넥션 {conn_after} ≥ 임계 {args.conn_threshold}'
                break

    print()
    print('=' * 78)
    print(f'종료 사유: {stop_reason}')
    if rows and args.conn_cmd:
        deltas = [r for r in rows if r['conn_before'] is not None and r['conn_after'] is not None]
        if deltas:
            print()
            print('커넥션 증감 (단계 시작 → 종료)')
            for r in deltas:
                d = r['conn_after'] - r['conn_before']
                mark = '  ← 누적' if d > 10 else ''
                print(f"  rps {r['rps']:6.1f}   {r['conn_before']:4d} → {r['conn_after']:4d}   "
                      f"({d:+d}){mark}")
            print()
            print('  증감이 0 근처로 유지되면 커넥션이 쌓이지 않는 것이고,')
            print('  단계마다 증가분이 누적되면 반납되지 않는 것이다.')
            print('  다만 한 번의 실행만으로는 풀 워밍업과 구분되지 않는다.')
            print('  같은 조건을 두 번 돌려 두 번째 증가분이 줄면 워밍업이다.')
    if rows and any(r.get('ttfb50') for r in rows):
        print()
        print('첫 바이트 시간이 전체 지연(p50)에 근접하면 응답이 스트리밍되지 않고')
        print('버퍼링된 것이다. 응답 가드레일을 켰을 때 이 값이 뛰는지 비교할 것.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
