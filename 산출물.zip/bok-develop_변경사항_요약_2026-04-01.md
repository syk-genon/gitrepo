# bok-develop 변경사항 요약 (2026-04-01 ~ 2026-07-23)

> 기준 브랜치: `bok-develop` (HEAD `b347205290`) / 비교 대상: `develop`
> 작성일: 2026-07-29

한국은행(BOK) 운영 배포 브랜치의 변경 내역을, **커밋된 작업**과 **아직 커밋되지 않은 워킹트리 변경**으로 나누어 정리한다.

---

## 1. 커밋된 작업 (14건)

`bok-develop`가 `develop` 대비 가진 고유 커밋 중 2026-04-01 이후 것. 신규 기능(feat) 1건을 제외하면 전부 운영 안정화·버그 수정(fix)이다.

### 1.1 보안 취약점 조치 (2건)

| 날짜 | 서비스 | 내용 | 규모 |
|---|---|---|---|
| 04-29 | chat-api | **시스템 프롬프트 노출** 취약점 조치 | +3 |
| 05-18 | chat-api | 임시 문서 다운로드/조회 **IDOR 취약점** 조치 | +2,092 / -2,052 |

### 1.2 HR/인사데이터 동기화 (cronjob, 2건)

| 날짜 | 내용 | 규모 |
|---|---|---|
| 04-29 | 인사데이터 배치 **주재원 인식 기능** 추가 | +13 / -2 |
| 05-28 | 인사데이터 배치 **주재원 관리그룹 매핑** 추가 | +125 / -6 |

### 1.3 서빙 / 워크플로우 (flowise·orchestrator·gateway, 5건)

| 날짜 | 내용 | 규모 |
|---|---|---|
| 04-07 | [admin-api·gateway-api·orchestrator] 외부 서빙 body/params **중첩 JSON 객체 지원** | +72 / -25 |
| 04-07 | [flowise300] **워크플로우 서빙 리스트 무한로딩** 수정 | +3 / -3 |
| 06-18 | [admin-api] 외부 서빙 **대표 리비전 헤더 전달 오류** 수정 | +10 / -2 |
| 07-13 | [flowise] 에이전트 워크플로우 **fd/메모리 누수 수정** (싱글턴 overlay 방식) | +461 |
| 07-21 | [orchestrator] 코드스페이스 파드에 **nfs-root PVC 마운트** 추가 (유일한 feat) | +5 |

### 1.4 채팅 통계 / 로그 (admin-api·admin-front, 3건)

| 날짜 | 내용 | 규모 |
|---|---|---|
| 04-07 | [admin-api] **활성 채팅 통계 집계 로직** 수정 | +11 / -7 |
| 04-08 | [admin-api·admin-front] 채팅 로그 용량에 따른 **다운로드 무한로딩** 수정 | +24 / -12 |
| 04-30 | [admin-api] 채팅 통계가 **리비전 수만큼 나오는 에러** 수정 | +3 / -4 |

### 1.5 기타 (2건)

| 날짜 | 내용 | 규모 |
|---|---|---|
| 04-29 | [admin-api] **90일 계정 비활성화 기능 비활성화** | +6 / -6 |
| 07-22 | [front] **비활동 자동 로그아웃 비활성화** | +28 / -27 |

---

## 2. 종합

| 구분 | 건수 | 요지 |
|---|---|---|
| 커밋된 작업 | 14 | 보안 취약점 2건, HR 주재원 처리, 서빙/flowise 안정화, 채팅 통계·로그 수정 |
| 미커밋 실변경 | 8개 파일 | BOK 폐쇄망 빌드/배포 설정 (사내 Harbor, apk http, strict-ssl, pymysql) |
| Untracked | 3 | k8s 동기화 스크립트 1 + 산출물 문서 2 |
| 노이즈 | ~3,701개 파일 | CRLF→LF 줄끝 변경 (실제 코드 변경 아님) |

### 2.1 날짜별 정리 (커밋된 작업 14건)

오래된 순 정렬. **07-21·07-22 2건은 아직 스테이징 서버 테스트 중이며 운영에는 반영되지 않았다. (07-13 flowise fd/메모리 누수 수정은 운영 반영 완료)**

| 날짜 | 반영 상태 | 서비스 | 내용 | 규모 |
|---|---|---|---|---|
| 04-07 | 운영 반영 | admin-api | 활성 채팅 통계 집계 로직 수정 | +11 / -7 |
| 04-07 | 운영 반영 | admin-api·gateway-api·orchestrator | 외부 서빙 body/params 중첩 JSON 객체 지원 | +72 / -25 |
| 04-07 | 운영 반영 | flowise300 | 워크플로우 서빙 리스트 무한로딩 수정 | +3 / -3 |
| 04-08 | 운영 반영 | admin-api·admin-front | 채팅 로그 용량에 따른 다운로드 무한로딩 수정 | +24 / -12 |
| 04-29 | 운영 반영 | chat-api | 시스템 프롬프트 노출 취약점 조치 | +3 |
| 04-29 | 운영 반영 | cronjob | 인사데이터 배치 주재원 인식 기능 추가 | +13 / -2 |
| 04-29 | 운영 반영 | admin-api | 90일 계정 비활성화 기능 비활성화 | +6 / -6 |
| 04-30 | 운영 반영 | admin-api | 채팅 통계가 리비전 수만큼 나오는 에러 수정 | +3 / -4 |
| 05-18 | 운영 반영 | chat-api | 임시 문서 다운로드/조회 IDOR 취약점 조치 | +2,092 / -2,052 |
| 05-28 | 운영 반영 | cronjob | 인사데이터 배치 주재원 관리그룹 매핑 추가 | +125 / -6 |
| 06-18 | 운영 반영 | admin-api | 외부 서빙 대표 리비전 헤더 전달 오류 수정 | +10 / -2 |
| 07-13 | 운영 반영 | flowise | 에이전트 워크플로우 fd/메모리 누수 수정 (싱글턴 overlay) | +461 |
| 07-21 | 운영 미반영 | orchestrator | 코드스페이스 파드에 nfs-root PVC 마운트 추가 (feat) | +5 |
| 07-22 | 운영 미반영 | front | 비활동 자동 로그아웃 비활성화 | +28 / -27 |

---

## 3. 에러 로그 필터링 쿼리 (Kibana)

운영 에러 로그에서 **자가복구·정상흐름·모델출력 노이즈를 제외**하고 실제 문제만 남기기 위한 KQL 쿼리. 치명적 에러(미처리 예외 등)를 가릴 위험이 있는 절은 의도적으로 제외했다.

### 3.1 최종 쿼리

```
message:error and not message: "DEBUG" and not message:"Exception during reset or similar" and not message:"reconstruction error" and not message:"squared prediction error" and not message:"error covariance" and not message: "catch error" and not message:"StreamLostError" and not message:"Transport indicated EOF" and not message:"Socket EOF" and not message:"watch_container_services" and not message:"session-expired" and not message:"01020002" and not message:"Bearer token required" and not message:"Invalid MCP Server Config"
```

### 3.2 각 절 설명

| 절 | 대상 | 성격 |
|---|---|---|
| `message:error` | ERROR 토큰이 포함된 로그만 조회 (기준) | base |
| `not "DEBUG"` | DEBUG 레벨 로그 | 레벨 노이즈 |
| `not "Exception during reset or similar"` | SQLAlchemy 커넥션 풀 반환 시 reset 실패 로그 | DB 풀 노이즈(저위험) |
| `not "reconstruction error"` | flowise 모델 출력 텍스트 | 모델 출력(에러 아님) |
| `not "squared prediction error"` | flowise 모델 출력 텍스트 | 모델 출력(에러 아님) |
| `not "error covariance"` | flowise 모델 출력 텍스트 | 모델 출력(에러 아님) |
| `not "catch error"` | flowise/노드 출력 텍스트 | 모델 출력(에러 아님) |
| `not "StreamLostError"` | log-server ↔ RabbitMQ 연결 끊김 | 자가복구(재연결) |
| `not "Transport indicated EOF"` | 동일 RabbitMQ 끊김 cascade | 자가복구 |
| `not "Socket EOF"` | 동일 RabbitMQ 소켓 EOF | 자가복구 |
| `not "watch_container_services"` | container-status-collector의 Prometheus 조회 실패(빈 메시지) | 다음 tick 재시도 |
| `not "session-expired"` | chat-api 세션 만료 시 존재하지 않는 endpoint로 404 유도 | 정상 흐름 |
| `not "01020002"` | 미등록/오타 사용자 조회 실패 | 사용자 입력 오류 |
| `not "Bearer token required"` | 인증 헤더 없는 게이트웨이 요청 | 클라이언트 미인증 |
| `not "Invalid MCP Server Config"` | MCP 서버 미배포/다운 시 DNS 해석 실패(`EAI_AGAIN`) | 인프라 상태(의도적 off) |

### 3.3 잔여 유의사항

- **MCP off 필터**는 원인 라인만 제거하며, 여파인 chat-api `Workflow API Call Failed` / workflow `Streaming error: category=unknown`은 다른 원인으로도 발생할 수 있어 제외하지 않음.
- **`01020002`** 는 정상 사용자의 프로비저닝 누락 사고와 코드가 동일하므로, 필터와 별개로 발생 건수를 대시보드로 모니터링 권장.
- `message:error`는 analyzed 토큰 매칭이라 `ValueError`처럼 `error`가 단독 토큰이 아닌 로그는 누락 가능 → 가능하면 로그 레벨 필드 기반 필터 병행.

---

## 4. 문의·확인 이력 (코드 변경 없음)

- 07-24 [flowise] `MaxListenersExceededWarning`(AbortSignal에 abort 리스너 11개 > Node 기본 10) 문의 → `@langchain/core` 스트리밍(raceWithSignal)의 기본 동작이며 별도 설정이 아닌 Node 기본 임계치(10) 초과 경고. 진단 결과 리스너·메모리 안정으로 **누수 아님 확인**, 조치 불요(원하면 부트스트랩에서 `events.setMaxListeners` 상향으로 경고만 억제 가능).
- 07-29 [infra/k8s] llmops **MinIO(Bitnami standalone) 리소스 튜닝 — 근본원인은 메모리, CPU 스로틀링은 증상**. **증상**: CPU limit 375m에서 사용량 ~370m·**스로틀링 97%**, 부하 시 **OOMKilled(Exit 137)**. **진단(실측)**: 메모리 limit **375Mi에 실사용 평균 ~372Mi(한계의 99% 상시 포화)** → Go 힙이 천장에 붙어 GC·reclaim 그레싱을 상시 수행 → 그 churn이 CPU를 태워(~368m) 375m CPU 쿼터를 순간 소진 → 97% throttle. 즉 CPU가 아니라 **메모리 부족이 뿌리**. **검증**: 메모리를 워킹셋(idle ~320Mi) 위로 올리자 CPU limit을 다시 375m로 되돌려도 부하 시 <100m 유지(스로틀 소멸) → CPU 1000m 상향은 증상만 가렸던 것으로 확인. 오브젝트 72,930개/3.4GiB(스캐너 메모리는 오브젝트 수 비례). **권장: memory limit ≥512Mi**(370Mi대에서 부하 시 OOM 발생했으므로 부하 워킹셋>375Mi, 400Mi는 마진 부족), **CPU는 375m로 충분**. 코드 변경 없음, 클러스터 Deployment 리소스만 변경(git 미반영).
