# GenOS 백업 시스템

단일 백업러너가 MariaDB / MongoDB / Weaviate / NFS 파일을 NFS `llmops-nfs-root`의 `backups/<DATE>/` 한 곳에 백업하고, 성공 시 비파괴 복원 테스트까지 이어서 검증하는 시스템.

> **검증 상태**: **스테이징 환경에서 전체 백업 → 복원 테스트까지 정상 동작 확인 완료.** (MariaDB / MongoDB / Weaviate 다노드 / NFS 폴더 백업 및 복원 검증 PASS)

## 개요

- **실행 형태**: K8s CronJob (격주, 매월 1·15일 02:00 KST). 단일 파드에서 4개 컴포넌트 병렬 백업.
- **이미지**: `llmops-backup-runner:1.2.0` (debian-slim + mariadb-client, mongodump/mongorestore/mongosh, kubectl, zstd, gzip, jq)
- **저장소**: NFS `llmops-nfs-root` PVC → `/nfs-root/backups/<YYYYMMDD_HHMMSS>/`
- **다운타임**: 0 (hot backup)

## 백업 대상 및 방식

| 컴포넌트 | 방식 | 산출물 | 정합성 |
|---|---|---|---|
| MariaDB (Galera) | `mariadb-dump --single-transaction --max-allowed-packet=1G` | `maria_<DATE>.sql.gz` | MVCC 스냅샷 (시간 무관 일관) |
| MongoDB (standalone) | `mongodump --gzip --archive` | `mongo_<DATE>.archive.gz` | 순차 덤프 (컬렉션 간 skew 가능) |
| Weaviate (다노드) | 노드 PVC 직접 마운트 후 `tar` (store) | `weaviate_node-<i>_<DATE>.tar` | 라이브 tar (재임베딩 가능) |
| NFS 파일 | 폴더별 개별 아카이브 | `nfs_<folder>_<DATE>.tar[.zst]` | 문서 immutable |

## 핵심 기능

- **폴더별 압축**: `docs / aiModel / models` 등 비압축성 폴더는 무압축 `tar`(store), 그 외는 `zstd`(`.tar.zst`). (`NFS_STORE_ONLY_DIRS`)
- **병렬 처리**: 4개 컴포넌트 병렬 + NFS 폴더 `NFS_PARALLEL`(기본 3)개 동시.
- **Weaviate 직접 마운트**: `kubectl exec`(API 서버 경유, ~2MB/s) 대신 노드 PVC 직접 tar(~60MB/s+). 다노드는 모든 노드 PVC 마운트 필요. 미마운트 시 exec 폴백.
- **인라인 체크섬**: NFS 아카이브는 tar 스트림을 `tee`로 흘리며 SHA-256 동시 계산(재읽기 0회).
- **진행률/ETA**: 30초 주기, **이번 런 실데이터(du) 기반**. `[진행] % | 경과 | NFS 처리율(완료/전체, 남은양) 남은시간 | maria ~ | mongo ~ | wev ~` — NFS 진행률·처리율·남은시간 + 컴포넌트별 상태(대기/진행중/완료/실패) 동시 표시.
- **보존 정책**: 백업 **시작 전** 오래된 것 삭제(공간 확보), 최신 `BACKUP_KEEP_LAST`(기본 2)개 유지.
- **이력 로그**: `backups/backup_history.log`에 런당 1줄 (`maria OK(9.6G) | mongo OK(2.1G) | ...`).
- **자동 복원 테스트**: 백업 성공 시 방금 만든 백업을 비파괴 검증까지 이어서 실행 (`RUN_RESTORE_TEST=true`).

## 복원 테스트 (비파괴)

DB/PVC에 아무것도 쓰지 않고 백업 파일만 읽어 "복원 가능성"을 검증.

| 검사 | 내용 |
|---|---|
| [1] 무결성+체크섬 | 아카이브당 1회 읽기, `RESTORE_PARALLEL`개 병렬. MANIFEST SHA-256 일치=무결성 보장 (없으면 압축 해제 검증) |
| [2] MariaDB | `Dump completed` 마커 + CREATE TABLE 수 (덤프 절단 감지) |
| [3] MongoDB | mongodump 아카이브 매직넘버(`6de29981`) 확인 (서버 불필요) |
| [4] Weaviate | 노드별 존재 + **노드 수 완전성**(`WEAVIATE_REPLICAS`와 일치, 누락=FAIL) |
| [5] NFS | 아카이브 개수 |

## 용량 사전 예상

`estimate_size.sh` — 백업 없이 `du`/DB 쿼리로 원본 크기 예상 (nfs 폴더별 + weaviate 노드별 + MariaDB + MongoDB).

## 구성 요소

**스크립트** (`scripts/`, ConfigMap `llmops-backup-scripts`로 마운트)
- `run_backup.sh` — 통합 진입점 (readiness 대기 → 사전체크 → 사전 cleanup → 병렬 백업 → 매니페스트 → 이력 → 복원테스트)
- `pre_backup_chk.sh` — 사전 정합성 체크
- `restore_test.sh` — 비파괴 복원 검증
- `estimate_size.sh` — 용량 예상

**매니페스트** (`k8s/`)
- `backup-runner.txt` — SA / Role / RoleBinding / Secret + 일회성 Job
- `backup-cronjob.txt` — 정기 백업 CronJob
- `restore-test.txt` — 복원 테스트 단독 Job
- `estimate-size.txt` — 용량 예상 Job
- `maria-redump.txt` — MariaDB만 재덤프(실패 백업 패치)

## 배포 방법

```bash
# 1) 이미지 로드 (각 노드)
gunzip -c llmops-backup-runner-1.2.0.tar.gz | ctr -n k8s.io image import -

# 2) 전제 리소스 (SA/Role/RoleBinding/Secret) — Secret <FILL_ME> 채운 후
kubectl apply -f k8s/backup-runner.txt

# 3) 스크립트 ConfigMap
kubectl create configmap llmops-backup-scripts -n llmops \
  --from-file=scripts/pre_backup_chk.sh \
  --from-file=scripts/run_backup.sh \
  --from-file=scripts/restore_test.sh \
  --from-file=scripts/estimate_size.sh \
  --dry-run=client -o yaml | kubectl apply -f -

# 4) 정기 백업 (성공 시 복원테스트 자동)
kubectl apply -f k8s/backup-cronjob.txt

# 수동 1회 실행
kubectl create job --from=cronjob/llmops-backup-runner llmops-backup-manual-001 -n llmops
kubectl logs -f -n llmops job/llmops-backup-manual-001
```

## 주요 환경변수

| 변수 | 기본 | 설명 |
|---|---|---|
| `WEAVIATE_REPLICAS` | 3 | weaviate 노드 수 (테스트 1, 운영 3) |
| `WEAVIATE_DATA_BASE` | /weaviate-data | 노드별 마운트 `/weaviate-data-<i>` |
| `NFS_STORE_ONLY_DIRS` | docs aiModel models | 무압축(store) 폴더 |
| `NFS_PARALLEL` | 3 | NFS 폴더 동시 처리 수 |
| `BACKUP_SHA256` | true | 인라인 체크섬 |
| `BACKUP_KEEP_LAST` | 2 | 보존 백업 수 |
| `MARIA_MAX_PACKET` | 1G | mariadb-dump 패킷 크기 |
| `RUN_RESTORE_TEST` | true | 백업 후 복원테스트 이어실행 |
| `PROGRESS_INTERVAL` | 30 | 진행률 리포트 주기(초) |

## 운영(3노드) 전환

`backup-cronjob.txt`에서:
- `WEAVIATE_REPLICAS` → `"3"`
- `weaviate-data-1`, `weaviate-data-2` volumeMount + volume 주석 해제

## 정합성 / 성능 참고

- **MariaDB**: `--single-transaction`으로 시간과 무관하게 일관 (문제없음).
- **MongoDB**: standalone이라 point-in-time 불가 → 긴 덤프 중 컬렉션 간 skew 가능. 새벽 저트래픽으로 완화. replica set 전환 시 `--oplog` 권장. **총시간 병목**(mongodump이 느림).
- **Weaviate**: 라이브 tar라 정합성 리스크 있으나, 원본 문서(`docs`)로 재임베딩 가능하므로 치명적이지 않음.
- **CSI 볼륨 스냅샷 불가**: `nfs-client`(비-CSI) 프로비저너라 k8s 스냅샷 미지원. NAS 레벨 스냅샷은 스토리지팀 확인 필요.
- **리소스**: CPU limit 4 / memory 4Gi. 백업 중 공유 NFS 대역·mongo 서버 부하로 다른 파드 영향 가능 → 새벽 배치로 완화.

## 알려진 이슈 / 해결

| 증상 | 원인 | 해결 |
|---|---|---|
| `Error 2013: lost connection ... at row N` | mariadb-dump 기본 max_allowed_packet(16MB) 초과 행 | `--max-allowed-packet=1G` (반영됨) |
| 복원테스트 "command not found" 다발 | ConfigMap 누락 또는 CRLF 줄바꿈 | LF로 ConfigMap 재생성 |
| `ServiceAccount not found` | `backup-runner.txt` 미적용 | SA/Secret 먼저 적용 |
| Weaviate `weaviate-1 not found` | `WEAVIATE_REPLICAS` 실제 노드 수 불일치 | 노드 수에 맞춤 |
| 실패 백업의 maria만 복구 | — | `maria-redump.txt` (해당 dir 패치 + MANIFEST 갱신) |

## 산출물

- 배포 번들: `docker_img/llmops-backup-bundle.tar.gz` (이미지 1.2.0 + 스크립트 + 매니페스트 + 문서)
