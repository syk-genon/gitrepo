# Node.js 2026-10 CVE 대응 — 반입 이미지 목록 (HAN-46)

- 작성일: 2026-10-27
- 기준: 로컬 저장소 `bok-develop` 브랜치
- 대상 CVE: CVE-2026-111497(Node2Shell, Brotli RCE, EOL 18/20 포함), CVE-2026-105482, CVE-2026-106069, CVE-2026-105483
- 수정 버전: 22.23.4 / 24.22.1 / 26.12.1 (18·20은 EOL → 22로 메이저 상향)

## 수정 범위 (로컬 저장소)

| 대상 | 수량 |
|---|---|
| Dockerfile | 28개 (FROM 55줄) |
| `.nvmrc` | 8개 |
| flowise `package.json` engines | 3곳 (`>=18.15.0 <19.0.0 \|\| ^20` → Node 22 범위 밖) |
| langfuse 매니페스트 | 1개 |

## 반입 대상 이미지: 8개

`k8s-manifests`에 배포 매니페스트가 있는 이미지만 집계.

| # | 이미지 | 빌드 스크립트 | Dockerfile | Node 변경 |
|---|---|---|---|---|
| 1 | `llmops-admin-front` | `scripts/build/build_admin_front.sh` | `admin-front/Dockerfile` | 22.9.0 → 22.23.4 (패치) |
| 2 | `llmops-report-front` | `scripts/build/build_report_front.sh` | `report-front/Dockerfile` | 22.9.0 → 22.23.4 (패치) |
| 3 | `llmops-chat-front` | `scripts/build/build_chat_front.sh` | `chat-front/Dockerfile` | 18.17.0 → 22 (메이저) |
| 4 | `app-data-analysis-front` | `scripts/build/build_app_data_analysis_front.sh` | `app-data-analysis-front/Dockerfile` | 18.17.0 → 22 (메이저) |
| 5 | `llmops-flowise-180` | `scripts/build/build_flowise_180.sh` | `flowise/1.8.0/Dockerfile` | 20-alpine → 22 (메이저) |
| 6 | `llmops-flowise-223` | `scripts/build/build_flowise_223.sh` | `flowise/2.2.3/Dockerfile` | 20-alpine → 22 (메이저) |
| 7 | `llmops-flowise-300` | `scripts/build/build_flowise_300.sh` | `flowise/3.0.0/Dockerfile` | 20-alpine → 22 (메이저) |
| 8 | `langfuse:2.79` | `scripts/build/build_langfuse.sh` | `langfuse-2.79.0/web/Dockerfile` (업스트림) | 20 → 22 (메이저) |

## 제외

| 이미지 | 사유 |
|---|---|
| `llmops-app-front` | 빌드 스크립트는 있으나 배포 매니페스트 없음 |
| `app-front/apps/*` (chat, data-analysis, report, user) | 이미지 배포 경로 없음 |
| `admin-front-vue` (18.16.0) | 빌드 스크립트·매니페스트 모두 없음 |

운영에서 실제로 안 쓰는지는 확인하지 않았다(저장소 기준 판단).

## 줄일 수 있는 경우

- flowise-180·223이 한국은행 운영에 떠 있지 않으면 **6개**. 확인: `kubectl -n llmops get deploy | grep -E 'front|flowise|langfuse'`
- 22 라인 패치만 1차로 반영하면 **2개**(#1·#2)로 끝난다. 나머지 6개는 메이저 상향이라 flowise engines 수정·빌드 검증이 필요하다.

## 참고

- flowise는 body-parser 2.x를 쓰며 br 인코딩 요청 본문을 기본 디코딩 → CVE-2026-111497 노출 경로
- 반입 tar는 `buildx --provenance=false --output type=docker`로 생성(nerdctl load ingest 에러 회피), 저장 위치 `/mnt/d/workspace/docker_img/`
