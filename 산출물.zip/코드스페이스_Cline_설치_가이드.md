# 코드스페이스 AI 코딩 에이전트(Cline) 설치 가이드

GenOS 코드스페이스(code-server)에 Cline을 설치하고 GenOS 서빙 API에 연결합니다. 소스 코드와 이미지는 수정하지 않습니다.

## 1. 반입 파일

| 파일 | 위치 | 비고 |
|---|---|---|
| `saoudrizwan.claude-dev-4.0.12.vsix` | `/mnt/d/workspace/docker_img/cline-codespace/` | 약 10MB, Open VSX 공식 배포본 |

- sha256: `27941f781874c827835dc9c5f0eff5d9c0f0861480eddeadb1485fb716deab82`
- 버전 고정 사유: 코드스페이스의 code-server 4.96.4는 VS Code 1.96 기반입니다. Cline 4.1.x는 VS Code `^1.101`을 요구해 설치할 수 없고, 4.0.12(엔진 `^1.84`)가 설치 가능한 최신 버전입니다.

## 2. 설치 (코드스페이스마다 1회)

1. 코드스페이스 VS Code를 열고 vsix 파일을 탐색기의 `/workspace`로 드래그해 업로드합니다.
2. 터미널에서 다음을 실행합니다.
   ```bash
   code-server --install-extension /workspace/saoudrizwan.claude-dev-4.0.12.vsix
   ```
   또는 확장 패널 → `...` → **Install from VSIX...**로 설치해도 됩니다.
3. 브라우저를 새로고침하면 좌측 액티비티 바에 Cline 아이콘이 나타납니다.

## 3. GenOS 서빙 연결

Cline 설정(톱니바퀴) → **API Provider: OpenAI Compatible**

| 항목 | 값 |
|---|---|
| Base URL | `http://llmops-gateway-api-service.llmops.svc:8080/rep/serving/{서빙ID}/v1` |
| API Key | GenOS 서빙 API 키 (서빙 상세 화면에서 발급) |
| Model ID | 서빙 모델명 (`GET {Base URL}/models`의 `id`) |
| Context Window | 서빙 `max_model_len` 값과 동일하게 입력 |
| Supports Images | 비전 모델이 아니면 해제 |

- 코드스페이스 파드는 클러스터 내부에 있으므로 내부 서비스 주소로 직접 호출합니다.
- 대표 리비전 경로(`/rep/serving/...`)가 동작하지 않으면 리비전을 지정한 경로 `/serving/{서빙ID}/{리비전ID}/v1`을 사용합니다. 대표 리비전 경로는 확인이 필요합니다.
- 연결 확인 (코드스페이스 터미널):
  ```bash
  curl -s http://llmops-gateway-api-service.llmops.svc:8080/rep/serving/{서빙ID}/v1/models \
    -H "Authorization: Bearer <API키>"
  ```

권장 설정
- Settings → **Telemetry: off** (폐쇄망에서는 외부 전송이 실패만 하고 기능에는 영향이 없습니다)
- Auto-approve는 기본(꺼짐)을 유지해 파일 수정과 명령 실행을 매번 승인합니다.

## 4. 사용

- Cline 패널에서 자연어로 요청합니다. 예: "src 디렉토리 구조를 분석하고 user API에 페이지네이션을 추가해줘"
- **Plan 모드**에서는 코드를 읽고 분석해 계획만 세웁니다. **Act 모드**에서는 파일 생성/수정과 터미널 실행을 합니다.
- `@파일경로`, `@folder`로 컨텍스트를 직접 지정할 수 있습니다.

## 5. 모델 요구사항

Cline은 도구 호출(파일 읽기/쓰기, 명령 실행)과 긴 컨텍스트에 의존합니다.
- 권장: 코딩 특화 모델 30B 이상 (Qwen3-Coder, Qwen2.5-Coder-32B-Instruct 급)
- 컨텍스트: 32K 이상 권장. 짧으면 큰 파일을 분석하다 중단됩니다.
- 소형 모델에서는 "출력 형식 오류"와 "도구 호출 실패"가 반복될 수 있습니다.

## 6. 제약사항

- 확장과 Cline 설정은 `/root/.local/share/code-server/`에 저장되며 PVC가 아닙니다. **코드스페이스를 재시작하거나 재생성하면 다시 설치하고 설정해야 합니다.** vsix를 `/workspace`(PVC)에 두면 2단계 명령만 다시 실행하면 됩니다.
- 영구 적용(이미지 내장, 연결 정보 자동 주입)이 필요하면 이미지 수정이 필요합니다. 별도 작업으로 진행합니다.
